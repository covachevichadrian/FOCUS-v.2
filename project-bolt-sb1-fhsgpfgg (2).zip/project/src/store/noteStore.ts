import { create } from 'zustand';
import { supabase } from '../lib/supabase';

export interface Note {
  id: string;
  user_id: string;
  title: string;
  content: string | null;
  created_at: string;
  updated_at: string;
  position: number;
  reminder_at: string | null;
  reminder_sent: boolean;
}

interface NoteState {
  notes: Note[];
  loading: boolean;
  createNote: (title: string, content?: string, reminderAt?: Date) => Promise<void>;
  deleteNote: (id: string) => Promise<void>;
  updateNote: (id: string, title: string, content?: string, reminderAt?: Date | null) => Promise<void>;
  reorderNotes: (notes: Note[]) => Promise<void>;
  fetchNotes: () => Promise<void>;
}

export const useNoteStore = create<NoteState>((set, get) => ({
  notes: [],
  loading: true,
  createNote: async (title, content, reminderAt) => {
    const minPosition = Math.min(...get().notes.map(n => n.position), 0);
    const newPosition = minPosition - 1;

    const { data: note, error } = await supabase
      .from('notes')
      .insert({ 
        title,
        content,
        position: newPosition,
        reminder_at: reminderAt?.toISOString(),
        reminder_sent: false
      })
      .select()
      .single();

    if (error) {
      console.error('Failed to create note:', error);
      throw error;
    }
    set({ notes: [note, ...get().notes] });
  },
  deleteNote: async (id) => {
    const { error } = await supabase
      .from('notes')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Failed to delete note:', error);
      throw error;
    }
    set({ notes: get().notes.filter(n => n.id !== id) });
  },
  updateNote: async (id, title, content, reminderAt) => {
    const { data: updatedNote, error } = await supabase
      .from('notes')
      .update({ 
        title, 
        content,
        reminder_at: reminderAt?.toISOString(),
        reminder_sent: false,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Failed to update note:', error);
      throw error;
    }
    set({
      notes: get().notes.map(n => n.id === id ? updatedNote : n)
    });
  },
  reorderNotes: async (reorderedNotes) => {
    const updates = reorderedNotes.map((note) => ({
      id: note.id,
      title: note.title,
      content: note.content,
      position: note.position,
      reminder_at: note.reminder_at,
      reminder_sent: note.reminder_sent,
      updated_at: note.updated_at
    }));

    const { error } = await supabase
      .from('notes')
      .upsert(updates, { 
        onConflict: 'id',
        ignoreDuplicates: false
      });

    if (error) {
      console.error('Failed to reorder notes:', error);
      throw error;
    }

    set({ notes: reorderedNotes });
  },
  fetchNotes: async () => {
    const { data: notes, error } = await supabase
      .from('notes')
      .select('*')
      .order('position', { ascending: true });

    if (error) {
      console.error('Failed to fetch notes:', error);
      throw error;
    }
    set({ notes, loading: false });
  },
}));