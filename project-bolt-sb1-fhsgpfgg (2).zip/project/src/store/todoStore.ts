import { create } from 'zustand';
import { supabase } from '../lib/supabase';

export interface Todo {
  id: string;
  user_id: string;
  title: string;
  description?: string | null;
  completed: boolean;
  reminder_at: string | null;
  reminder_sent: boolean;
  created_at: string;
  position: number;
}

interface TodoState {
  todos: Todo[];
  loading: boolean;
  createTodo: (title: string, description?: string, reminderAt?: Date) => Promise<void>;
  toggleTodo: (id: string) => Promise<void>;
  deleteTodo: (id: string) => Promise<void>;
  updateReminder: (id: string, reminderAt: Date | null) => Promise<void>;
  updateTodo: (id: string, title: string, description?: string) => Promise<void>;
  reorderTodos: (todos: Todo[]) => Promise<void>;
  fetchTodos: () => Promise<void>;
}

export const useTodoStore = create<TodoState>((set, get) => ({
  todos: [],
  loading: true,
  createTodo: async (title, description, reminderAt) => {
    // Get the minimum position and subtract 1 to place at the top
    const minPosition = Math.min(...get().todos.map(t => t.position), 0);
    const newPosition = minPosition - 1;

    const { data: todo, error } = await supabase
      .from('todos')
      .insert({ 
        title,
        description,
        reminder_at: reminderAt?.toISOString(),
        reminder_sent: false,
        position: newPosition
      })
      .select()
      .single();

    if (error) {
      console.error('Failed to create todo:', error);
      throw error;
    }

    set({ todos: [todo, ...get().todos] });
  },
  toggleTodo: async (id) => {
    const todo = get().todos.find(t => t.id === id);
    if (!todo) return;

    const { data: updatedTodo, error } = await supabase
      .from('todos')
      .update({ completed: !todo.completed })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Failed to toggle todo:', error);
      throw error;
    }

    set({
      todos: get().todos.map(t => t.id === id ? updatedTodo : t)
    });
  },
  deleteTodo: async (id) => {
    const { error } = await supabase
      .from('todos')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Failed to delete todo:', error);
      throw error;
    }
    set({ todos: get().todos.filter(t => t.id !== id) });
  },
  updateReminder: async (id, reminderAt) => {
    const { data: updatedTodo, error } = await supabase
      .from('todos')
      .update({ 
        reminder_at: reminderAt?.toISOString(),
        reminder_sent: false
      })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Failed to update reminder:', error);
      throw error;
    }

    set({
      todos: get().todos.map(t => t.id === id ? updatedTodo : t)
    });
  },
  updateTodo: async (id, title, description) => {
    const { data: updatedTodo, error } = await supabase
      .from('todos')
      .update({ title, description })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Failed to update todo:', error);
      throw error;
    }

    set({
      todos: get().todos.map(t => t.id === id ? updatedTodo : t)
    });
  },
  reorderTodos: async (reorderedTodos) => {
    // Create updates that preserve all required fields
    const updates = reorderedTodos.map((todo) => ({
      id: todo.id,
      title: todo.title,
      position: todo.position,
      completed: todo.completed,
      reminder_at: todo.reminder_at,
      reminder_sent: todo.reminder_sent,
      description: todo.description
    }));

    const { error } = await supabase
      .from('todos')
      .upsert(updates, { 
        onConflict: 'id',
        ignoreDuplicates: false
      });

    if (error) {
      console.error('Failed to reorder todos:', error);
      throw error;
    }

    set({ todos: reorderedTodos });
  },
  fetchTodos: async () => {
    const { data: todos, error } = await supabase
      .from('todos')
      .select('*')
      .order('position', { ascending: true });

    if (error) {
      console.error('Failed to fetch todos:', error);
      throw error;
    }
    set({ todos, loading: false });
  },
}));