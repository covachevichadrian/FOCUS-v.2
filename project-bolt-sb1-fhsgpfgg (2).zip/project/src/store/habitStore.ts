import { create } from 'zustand';
import { supabase } from '../lib/supabase';

export interface Habit {
  id: string;
  user_id: string;
  name: string;
  created_at: string;
  streak: number;
  active_days: number[];
}

export interface HabitCompletion {
  id: string;
  habit_id: string;
  completed_at: string;
  created_at: string;
}

interface HabitState {
  habits: Habit[];
  completions: HabitCompletion[];
  loading: boolean;
  createHabit: (name: string, activeDays: number[]) => Promise<void>;
  deleteHabit: (id: string) => Promise<void>;
  toggleHabitCompletion: (habitId: string, date: Date) => Promise<void>;
  fetchHabits: () => Promise<void>;
  fetchCompletions: () => Promise<void>;
}

export const useHabitStore = create<HabitState>((set, get) => ({
  habits: [],
  completions: [],
  loading: true,
  createHabit: async (name, activeDays) => {
    try {
      const { data: habit, error } = await supabase
        .from('habits')
        .insert({ 
          name, 
          active_days: activeDays,
          streak: 0
        })
        .select()
        .single();

      if (error) throw error;
      if (!habit) throw new Error('No habit returned after creation');

      set({ habits: [...get().habits, habit] });
    } catch (error) {
      console.error('Failed to create habit:', error);
      throw error;
    }
  },
  deleteHabit: async (id) => {
    try {
      const { error } = await supabase
        .from('habits')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      set({ 
        habits: get().habits.filter(h => h.id !== id),
        completions: get().completions.filter(c => c.habit_id !== id)
      });
    } catch (error) {
      console.error('Failed to delete habit:', error);
      throw error;
    }
  },
  toggleHabitCompletion: async (habitId, date) => {
    try {
      const dateStr = date.toISOString().split('T')[0];
      const existing = get().completions.find(
        c => c.habit_id === habitId && c.completed_at.startsWith(dateStr)
      );

      if (existing) {
        // Delete existing completion
        const { error: deleteError } = await supabase
          .from('habit_completions')
          .delete()
          .eq('id', existing.id);

        if (deleteError) throw deleteError;

        // Update local state
        set({
          completions: get().completions.filter(c => c.id !== existing.id)
        });
      } else {
        // Create new completion
        const { data: completion, error: insertError } = await supabase
          .from('habit_completions')
          .insert({
            habit_id: habitId,
            completed_at: date.toISOString()
          })
          .select()
          .single();

        if (insertError) throw insertError;
        if (!completion) throw new Error('No completion returned after creation');

        // Update local state
        set({
          completions: [...get().completions, completion]
        });
      }

      // Fetch updated habit to get new streak
      const { data: habits, error: habitError } = await supabase
        .from('habits')
        .select()
        .eq('id', habitId);

      if (habitError) throw habitError;
      if (!habits || habits.length === 0) throw new Error('Habit not found');

      set({
        habits: get().habits.map(h => h.id === habitId ? habits[0] : h)
      });
    } catch (error) {
      console.error('Failed to toggle habit completion:', error);
      throw error;
    }
  },
  fetchHabits: async () => {
    try {
      const { data: habits, error } = await supabase
        .from('habits')
        .select()
        .order('created_at', { ascending: true });

      if (error) throw error;
      set({ habits: habits || [], loading: false });
    } catch (error) {
      console.error('Failed to fetch habits:', error);
      set({ habits: [], loading: false });
      throw error;
    }
  },
  fetchCompletions: async () => {
    try {
      const { data: completions, error } = await supabase
        .from('habit_completions')
        .select()
        .order('completed_at', { ascending: false });

      if (error) throw error;
      set({ completions: completions || [] });
    } catch (error) {
      console.error('Failed to fetch completions:', error);
      set({ completions: [] });
      throw error;
    }
  }
}));