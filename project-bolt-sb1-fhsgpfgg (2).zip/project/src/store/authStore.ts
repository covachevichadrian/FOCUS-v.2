import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { User, AuthError } from '@supabase/supabase-js';

interface AuthState {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<{ confirmationSent: boolean }>;
  signOut: () => Promise<void>;
  setUser: (user: User | null) => void;
  resendConfirmation: (email: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updatePassword: (password: string) => Promise<void>;
}

function getAuthErrorMessage(error: AuthError): string {
  switch (error.message) {
    // Sign in errors
    case 'Invalid login credentials':
      return 'El correo o la contraseña son incorrectos';
    case 'Email not confirmed':
      return 'Por favor, confirma tu correo electrónico antes de iniciar sesión';
    case 'Invalid email or password':
      return 'El correo o la contraseña son incorrectos';
    case 'User not found':
      return 'No existe una cuenta con este correo electrónico';
    
    // Sign up errors
    case 'User already registered':
      return 'Ya existe una cuenta con este correo electrónico';
    case 'Signup requires a valid password':
      return 'La contraseña debe tener al menos 8 caracteres';
    case 'Password should be at least 6 characters':
      return 'La contraseña debe tener al menos 8 caracteres';
    
    // Reset password errors
    case 'Email rate limit exceeded':
      return 'Has enviado demasiadas solicitudes. Por favor, espera unos minutos';
    case 'Password update requires an email':
      return 'Se requiere un correo electrónico para restablecer la contraseña';
    case 'Password update requires a new password':
      return 'Se requiere una nueva contraseña';
    
    // Network errors
    case 'Failed to fetch':
      return 'Error de conexión. Por favor, verifica tu conexión a internet';
    case 'Network request failed':
      return 'Error de conexión. Por favor, verifica tu conexión a internet';
    
    // Generic errors
    case 'Service not available':
      return 'El servicio no está disponible en este momento. Por favor, inténtalo más tarde';
    case 'Rate limit exceeded':
      return 'Demasiados intentos. Por favor, espera unos minutos';
    
    // Default error
    default:
      return 'Ha ocurrido un error. Por favor, inténtalo de nuevo';
  }
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  signIn: async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) {
        throw new Error(getAuthErrorMessage(error));
      }
      
      if (!data?.user) {
        throw new Error('No se pudo iniciar sesión');
      }
      
      set({ user: data.user, loading: false });
    } catch (error) {
      console.error('Error signing in:', error);
      throw error;
    }
  },
  signUp: async (email, password) => {
    try {
      if (password.length < 8) {
        throw new Error('La contraseña debe tener al menos 8 caracteres');
      }

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`,
          data: {
            confirmed_at: null
          }
        }
      });
      
      if (error) {
        throw new Error(getAuthErrorMessage(error));
      }
      
      if (!data?.user) {
        throw new Error('No se pudo crear la cuenta');
      }

      // Don't set the user yet - wait for email confirmation
      return { confirmationSent: true };
    } catch (error) {
      console.error('Error signing up:', error);
      throw error;
    }
  },
  signOut: async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        throw new Error(getAuthErrorMessage(error));
      }
      set({ user: null });
      localStorage.clear();
    } catch (error) {
      console.error('Error signing out:', error);
      throw error;
    }
  },
  setUser: (user) => set({ user, loading: false }),
  resendConfirmation: async (email) => {
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`
        }
      });

      if (error) {
        throw new Error(getAuthErrorMessage(error));
      }
    } catch (error) {
      console.error('Error resending confirmation:', error);
      throw error;
    }
  },
  resetPassword: async (email) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/callback?type=recovery`
      });

      if (error) {
        throw new Error(getAuthErrorMessage(error));
      }
    } catch (error) {
      console.error('Error resetting password:', error);
      throw error;
    }
  },
  updatePassword: async (password) => {
    try {
      if (password.length < 8) {
        throw new Error('La contraseña debe tener al menos 8 caracteres');
      }

      const { error } = await supabase.auth.updateUser({
        password
      });

      if (error) {
        throw new Error(getAuthErrorMessage(error));
      }
    } catch (error) {
      console.error('Error updating password:', error);
      throw error;
    }
  }
}));