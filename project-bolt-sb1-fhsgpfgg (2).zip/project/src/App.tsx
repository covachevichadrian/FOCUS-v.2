import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { supabase } from './lib/supabase';
import { useAuthStore } from './store/authStore';
import { useHabitStore } from './store/habitStore';
import { useTodoStore } from './store/todoStore';
import { useNoteStore } from './store/noteStore';
import { requestNotificationPermission, registerServiceWorker, startReminderChecker, stopReminderChecker } from './lib/notifications';
import { Auth } from './components/Auth';
import { Dashboard } from './components/Dashboard';
import { HabitList } from './components/HabitList';
import { HabitStats } from './components/HabitStats';
import { TodoList } from './components/TodoList';
import { NoteList } from './components/NoteList';
import { Goal } from './components/Goal';
import { Layout } from './components/Layout';
import { ApiTest } from './components/ApiTest';

function App() {
  const { user, setUser } = useAuthStore();
  const { fetchHabits, fetchCompletions } = useHabitStore();
  const { fetchTodos } = useTodoStore();
  const { fetchNotes } = useNoteStore();

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      // Initialize notifications and service worker
      requestNotificationPermission();
      
      // Only register service worker if not in StackBlitz
      if (!window.location.hostname.includes('stackblitz')) {
        registerServiceWorker();
      }
      
      startReminderChecker();

      // Fetch data
      fetchHabits();
      fetchCompletions();
      fetchTodos();
      fetchNotes();
    } else {
      stopReminderChecker();
    }

    return () => {
      if (user) {
        stopReminderChecker();
      }
    };
  }, [user]);

  if (!user) {
    return <Auth />;
  }

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="habits" element={<HabitList />} />
          <Route path="habits/:id" element={<HabitStats />} />
          <Route path="todos" element={<TodoList />} />
          <Route path="notes" element={<NoteList />} />
          <Route path="goals" element={<Goal />} />
          <Route path="goals/:id" element={<Goal />} />
          <Route path="api-test" element={<ApiTest />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;