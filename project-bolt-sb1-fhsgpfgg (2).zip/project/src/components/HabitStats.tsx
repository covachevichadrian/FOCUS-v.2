import React, { useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useHabitStore } from '../store/habitStore';
import { useAIRecommendations } from '../lib/recommendations';
import { useBookRecommendations } from '../lib/books';
import { ArrowLeft, Calendar, Award, Zap, BookOpen, Lightbulb, Target, AlertTriangle } from 'lucide-react';
import { addDays } from 'date-fns';

export function HabitStats() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { habits, completions } = useHabitStore();
  const habit = habits.find(h => h.id === id);
  const { recommendations, loading: loadingRecs } = useAIRecommendations(habit);
  const { books, loading: loadingBooks } = useBookRecommendations(habit?.id);

  const stats = useMemo(() => {
    if (!habit) return [];

    const habitCompletions = completions
      .filter(c => c.habit_id === habit.id)
      .map(c => c.completed_at.split('T')[0]);

    const startDate = new Date(habit.created_at);
    const endDate = addDays(startDate, 90);
    const result = [];
    let currentDate = new Date(startDate);

    while (currentDate <= endDate) {
      const dayOfWeek = currentDate.getDay();
      
      if (habit.active_days.includes(dayOfWeek)) {
        const dateStr = currentDate.toISOString().split('T')[0];
        result.push({
          date: dateStr,
          completed: habitCompletions.includes(dateStr)
        });
      }

      currentDate.setDate(currentDate.getDate() + 1);
    }

    return result;
  }, [habit, completions]);

  if (!habit) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-lg p-6 text-center">
          <p className="text-gray-600">Hábito no encontrado</p>
          <button
            onClick={() => navigate('/habits')}
            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gray-900 hover:bg-gray-800"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Volver a hábitos
          </button>
        </div>
      </div>
    );
  }

  const getIconForType = (type: string) => {
    switch (type) {
      case 'tip':
        return <Lightbulb className="w-5 h-5" />;
      case 'milestone':
        return <Target className="w-5 h-5" />;
      case 'challenge':
        return <Award className="w-5 h-5" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5" />;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
      <div className="space-y-8">
        {/* Stats Section */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <button
              onClick={() => navigate('/habits')}
              className="text-gray-600 hover:text-gray-900 transition-colors duration-200"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">{habit.name}</h1>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <Zap className="w-5 h-5" />
                <span className="text-sm font-medium">Racha actual</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{habit.streak} días</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <Award className="w-5 h-5" />
                <span className="text-sm font-medium">Total completados</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">
                {completions.filter(c => c.habit_id === habit.id).length}
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <Calendar className="w-5 h-5" />
                <span className="text-sm font-medium">Días activos</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{habit.active_days.length}/7</p>
            </div>
          </div>

          {/* Circle Grid */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Historial</h2>
            <div className="grid grid-cols-10 gap-0.5 max-w-md mx-auto">
              {stats.map((day, index) => (
                <div
                  key={index}
                  className={`w-4 h-4 rounded-full transition-colors duration-200
                    ${day.completed 
                      ? 'bg-green-100 border border-green-200' 
                      : 'bg-gray-100 border border-gray-200'}`}
                  title={day.date}
                />
              ))}
            </div>
            <div className="mt-4 flex justify-center gap-8 text-sm text-gray-500">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-100 border border-green-200" />
                <span>Completado</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-gray-100 border border-gray-200" />
                <span>No completado</span>
              </div>
            </div>
          </div>
        </div>

        {/* Recommendations Section */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Recomendaciones</h2>
          
          {loadingRecs ? (
            <div className="text-center text-gray-500 py-8">
              Cargando recomendaciones...
            </div>
          ) : recommendations.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.map(rec => (
                <div 
                  key={rec.id}
                  className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200"
                >
                  <div className="flex items-start gap-3">
                    <div className={`
                      p-2 rounded-full
                      ${rec.type === 'tip' ? 'bg-blue-100 text-blue-600' : ''}
                      ${rec.type === 'milestone' ? 'bg-green-100 text-green-600' : ''}
                      ${rec.type === 'challenge' ? 'bg-purple-100 text-purple-600' : ''}
                      ${rec.type === 'warning' ? 'bg-red-100 text-red-600' : ''}
                    `}>
                      {getIconForType(rec.type)}
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-1">{rec.title}</h3>
                      <p className="text-sm text-gray-600">{rec.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-500 py-8">
              No hay recomendaciones disponibles
            </div>
          )}
        </div>

        {/* Book Recommendations Section */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              <span>Lecturas recomendadas</span>
            </div>
          </h2>
          
          {loadingBooks ? (
            <div className="text-center text-gray-500 py-8">
              Cargando recomendaciones de libros...
            </div>
          ) : books.length > 0 ? (
            <div className="grid grid-cols-1 gap-6">
              {books.map(book => (
                <div 
                  key={book.id}
                  className="flex gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200"
                >
                  {book.image_url && (
                    <img 
                      src={book.image_url} 
                      alt={book.title}
                      className="w-24 h-36 object-cover rounded-md shadow-sm"
                    />
                  )}
                  <div>
                    <h3 className="font-medium text-gray-900 mb-1">{book.title}</h3>
                    <p className="text-sm text-gray-600 mb-2">
                      {book.authors.join(', ')}
                    </p>
                    <p className="text-sm text-gray-600 mb-4">{book.description}</p>
                    {book.preview_link && (
                      <a
                        href={book.preview_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
                      >
                        Ver más información
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-500 py-8">
              No hay recomendaciones de libros disponibles
            </div>
          )}
        </div>
      </div>
    </div>
  );
}