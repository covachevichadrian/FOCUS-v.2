import React, { useState, useRef, useEffect, useCallback, memo, useMemo } from 'react';
import { Plus, Trash2, CheckCircle, Circle, GripVertical, ChevronDown, ChevronUp, Clock, Calendar } from 'lucide-react';
import { useTodoStore, type Todo } from '../store/todoStore';
import { format } from 'date-fns';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragStartEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface SortableTodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, title: string, description?: string, reminderAt?: Date | null) => void;
  isDragging?: boolean;
}

const SortableTodoItem = memo(({ 
  todo, 
  onToggle, 
  onDelete,
  onEdit,
  isDragging,
}: SortableTodoItemProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(todo.title);
  const [editDescription, setEditDescription] = useState(todo.description || '');
  const [reminderDate, setReminderDate] = useState(
    todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : ''
  );
  const [reminderTime, setReminderTime] = useState(
    todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : ''
  );
  
  const editRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (isEditing && editRef.current && !editRef.current.contains(event.target as Node)) {
        handleSave();
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isEditing, editTitle, editDescription, reminderDate, reminderTime]);

  useEffect(() => {
    if (!isEditing) {
      setEditTitle(todo.title);
      setEditDescription(todo.description || '');
      setReminderDate(todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : '');
      setReminderTime(todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : '');
    } else {
      titleRef.current?.focus();
    }
  }, [todo, isEditing]);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: todo.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition: isDragging ? 'none' : transition,
  };

  const handleSave = async () => {
    if (!editTitle.trim()) {
      setIsEditing(false);
      setEditTitle(todo.title);
      setEditDescription(todo.description || '');
      setReminderDate(todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : '');
      setReminderTime(todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : '');
      return;
    }

    let reminderAt: Date | null | undefined;
    if (reminderDate && reminderTime) {
      reminderAt = new Date(`${reminderDate}T${reminderTime}`);
    } else if (!reminderDate && !reminderTime) {
      reminderAt = null;
    }
    
    await onEdit(
      todo.id, 
      editTitle.trim(), 
      editDescription.trim() || undefined,
      reminderAt
    );
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSave();
    } else if (e.key === 'Escape') {
      setIsEditing(false);
      setEditTitle(todo.title);
      setEditDescription(todo.description || '');
      setReminderDate(todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : '');
      setReminderTime(todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : '');
    }
  };

  return (
    <li
      ref={setNodeRef}
      style={style}
      className={`flex items-start gap-3 p-4 bg-white/5 backdrop-blur-lg rounded-lg border border-white/10 
        hover:border-white/20 transition-all duration-200 group
        ${isDragging ? 'border-white/20 shadow-lg' : ''}`}
    >
      <button
        {...attributes}
        {...listeners}
        className="touch-none text-white/40 hover:text-white/60 transition-colors duration-200 cursor-grab active:cursor-grabbing mt-1"
      >
        <GripVertical className="w-5 h-5" />
      </button>
      
      <button
        onClick={() => onToggle(todo.id)}
        className="text-white/40 hover:text-white/60 transition-colors duration-200 mt-1"
      >
        {todo.completed ? (
          <CheckCircle className="w-5 h-5" />
        ) : (
          <Circle className="w-5 h-5" />
        )}
      </button>

      <div 
        ref={editRef}
        className="flex-1 min-w-0 cursor-pointer"
        onClick={() => !isEditing && setIsEditing(true)}
      >
        {isEditing ? (
          <div className="space-y-4">
            <input
              ref={titleRef}
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg 
                text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                transition-all duration-200"
              placeholder="Task title"
            />
            <textarea
              value={editDescription}
              onChange={(e) => setEditDescription(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg 
                text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                transition-all duration-200 min-h-[60px] resize-y"
              placeholder="Add a description (optional)"
            />
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-blue-200 mb-1">
                  Reminder Date
                </label>
                <input
                  type="date"
                  value={reminderDate}
                  onChange={(e) => setReminderDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg 
                    text-white focus:outline-none focus:border-blue-500/40
                    transition-all duration-200"
                />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium text-blue-200 mb-1">
                  Reminder Time
                </label>
                <input
                  type="time"
                  value={reminderTime}
                  onChange={(e) => setReminderTime(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg 
                    text-white focus:outline-none focus:border-blue-500/40
                    transition-all duration-200"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => {
                  setIsEditing(false);
                  setEditTitle(todo.title);
                  setEditDescription(todo.description || '');
                  setReminderDate(todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : '');
                  setReminderTime(todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : '');
                }}
                className="px-3 py-1 text-sm text-blue-200 hover:text-white 
                  transition-colors duration-200"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-3 py-1 text-sm bg-blue-500 text-white rounded-md 
                  hover:bg-blue-600 transition-colors duration-200"
              >
                Save
              </button>
            </div>
          </div>
        ) : (
          <>
            <h3 className={`text-white group-hover:text-blue-200 transition-colors duration-200
              ${todo.completed ? 'line-through opacity-50' : ''}`}>
              {todo.title}
            </h3>
            {todo.description && (
              <p className={`mt-1 text-sm text-blue-200/60 group-hover:text-blue-200/80 transition-colors duration-200
                ${todo.completed ? 'line-through opacity-50' : ''}`}>
                {todo.description}
              </p>
            )}
            {todo.reminder_at && (
              <div className="mt-2 flex items-center gap-1 text-xs text-blue-200/60">
                <Clock className="w-4 h-4" />
                <span>Due {format(new Date(todo.reminder_at), 'MMM d, h:mm a')}</span>
              </div>
            )}
            {!todo.reminder_at && (
              <div className="mt-2 flex items-center gap-1 text-xs text-blue-200/60">
                <Calendar className="w-4 h-4" />
                <span>Add reminder</span>
              </div>
            )}
          </>
        )}
      </div>

      <button
        onClick={() => onDelete(todo.id)}
        className="text-white/40 hover:text-white/60 transition-colors duration-200 mt-1 opacity-0 group-hover:opacity-100"
      >
        <Trash2 className="w-5 h-5" />
      </button>
    </li>
  );
});

SortableTodoItem.displayName = 'SortableTodoItem';

export function TodoList() {
  const [newTodo, setNewTodo] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [reminderDate, setReminderDate] = useState('');
  const [reminderTime, setReminderTime] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [showCompleted, setShowCompleted] = useState(false);
  
  const { 
    todos, 
    createTodo, 
    toggleTodo, 
    deleteTodo, 
    updateTodo,
    updateReminder,
    reorderTodos
  } = useTodoStore();

  const { incompleteTodos, completedTodos } = useMemo(() => {
    const incomplete = todos.filter(todo => !todo.completed)
      .sort((a, b) => a.position - b.position);
    const completed = todos.filter(todo => todo.completed)
      .sort((a, b) => a.position - b.position);
    return { incompleteTodos: incomplete, completedTodos: completed };
  }, [todos]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleCreateTodo = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTodo.trim()) return;
    
    try {
      let reminderAt: Date | undefined;
      if (reminderDate && reminderTime) {
        reminderAt = new Date(`${reminderDate}T${reminderTime}`);
      }
      
      await createTodo(newTodo, newDescription, reminderAt);
      setNewTodo('');
      setNewDescription('');
      setReminderDate('');
      setReminderTime('');
      setIsExpanded(false);
    } catch (error) {
      console.error('Failed to create todo:', error);
    }
  }, [newTodo, newDescription, reminderDate, reminderTime, createTodo]);

  const handleEdit = useCallback(async (id: string, title: string, description?: string, reminderAt?: Date | null) => {
    try {
      await updateTodo(id, title, description);
      if (reminderAt !== undefined) {
        await updateReminder(id, reminderAt);
      }
    } catch (error) {
      console.error('Failed to update todo:', error);
    }
  }, [updateTodo, updateReminder]);

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  }, []);

  const handleDragEnd = useCallback(async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);
    
    if (over && active.id !== over.id) {
      const oldIndex = todos.findIndex(t => t.id === active.id);
      const newIndex = todos.findIndex(t => t.id === over.id);
      
      const reorderedTodos = arrayMove(todos, oldIndex, newIndex).map((todo, index) => ({
        ...todo,
        position: index
      }));
      
      await reorderTodos(reorderedTodos);
    }
  }, [todos, reorderTodos]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-blue-950 text-white p-4 sm:p-8">
      <div className="max-w-4xl mx-auto pb-24">
        <form onSubmit={handleCreateTodo} className="mb-8">
          <div className="relative">
            <input
              type="text"
              value={newTodo}
              onChange={(e) => setNewTodo(e.target.value)}
              onFocus={() => setIsExpanded(true)}
              placeholder="Add a new task..."
              className="w-full pl-4 pr-12 py-3 bg-white/5 border border-white/10 rounded-lg 
                text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                transition-all duration-200"
            />
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-500 text-white rounded-lg 
                hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                focus:ring-offset-gray-900 transition-all duration-200"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>

          <div className={`overflow-hidden transition-[max-height,opacity] duration-300 ease-in-out ${
            isExpanded ? 'max-h-[400px] opacity-100 mt-4' : 'max-h-0 opacity-0'
          }`}>
            <div className="space-y-4 transform transition-transform duration-300 ease-in-out">
              <textarea
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                placeholder="Add a description (optional)"
                className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg 
                  text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                  transition-all duration-200 min-h-[60px] resize-y"
              />
              
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-blue-200 mb-1">
                    Reminder Date
                  </label>
                  <input
                    type="date"
                    value={reminderDate}
                    onChange={(e) => setReminderDate(e.target.value)}
                    className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg 
                      text-white focus:outline-none focus:border-blue-500/40
                      transition-all duration-200"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-blue-200 mb-1">
                    Reminder Time
                  </label>
                  <input
                    type="time"
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value)}
                    className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg 
                      text-white focus:outline-none focus:border-blue-500/40
                      transition-all duration-200"
                  />
                </div>
              </div>
            </div>
          </div>
        </form>

        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={incompleteTodos}
            strategy={verticalListSortingStrategy}
          >
            <ul className="space-y-3">
              {incompleteTodos.map(todo => (
                <SortableTodoItem
                  key={todo.id}
                  todo={todo}
                  onToggle={toggleTodo}
                  onDelete={deleteTodo}
                  onEdit={handleEdit}
                  isDragging={todo.id === activeId}
                />
              ))}
            </ul>
          </SortableContext>
        </DndContext>

        {completedTodos.length > 0 && (
          <div className="mt-8 border-t border-white/10 pt-6">
            <button
              onClick={() => setShowCompleted(!showCompleted)}
              className="inline-flex items-center gap-2 text-sm text-blue-200 hover:text-white 
                transition-colors duration-200 mb-4 group"
            >
              {showCompleted ? (
                <>
                  Hide completed tasks
                  <ChevronUp className="w-4 h-4 transition-transform duration-200 group-hover:-translate-y-0.5" />
                </>
              ) : (
                <>
                  Show completed tasks ({completedTodos.length})
                  <ChevronDown className="w-4 h-4 transition-transform duration-200 group-hover:translate-y-0.5" />
                </>
              )}
            </button>

            {showCompleted && (
              <div className="transition-all duration-200">
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragStart={handleDragStart}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext
                    items={completedTodos}
                    strategy={verticalListSortingStrategy}
                  >
                    <ul className="space-y-3">
                      {completedTodos.map(todo => (
                        <SortableTodoItem
                          key={todo.id}
                          todo={todo}
                          onToggle={toggleTodo}
                          onDelete={deleteTodo}
                          onEdit={handleEdit}
                          isDragging={todo.id === activeId}
                        />
                      ))}
                    </ul>
                  </SortableContext>
                </DndContext>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}