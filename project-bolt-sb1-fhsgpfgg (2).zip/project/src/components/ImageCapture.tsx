import React, { useRef, useState } from 'react';
import { Camera, X, AlertCircle, Upload } from 'lucide-react';

interface ImageCaptureProps {
  onCapture: (text: string) => void;
  onClose: () => void;
}

const GOOGLE_VISION_API_KEY = 'AIzaSyCQxHNdh-Yspe5WyKk7EmVdpEcDbagyadw';
const VISION_API_URL = `https://vision.googleapis.com/v1/images:annotate?key=${GOOGLE_VISION_API_KEY}`;

export function ImageCapture({ onCapture, onClose }: ImageCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startCamera = async () => {
    try {
      setError(null);
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to access camera';
      setError(`Camera error: ${errorMessage}`);
      console.error('Error accessing camera:', err);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const processImage = async (imageBlob: Blob) => {
    try {
      setIsProcessing(true);
      setError(null);

      // Convert blob to base64
      const base64Image = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64String = reader.result as string;
          // Remove data URL prefix
          const base64 = base64String.split(',')[1];
          resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(imageBlob);
      });

      // Prepare request to Google Cloud Vision API
      const requestBody = {
        requests: [
          {
            image: {
              content: base64Image
            },
            features: [
              {
                type: 'DOCUMENT_TEXT_DETECTION', // Better for dense text
                maxResults: 1
              },
              {
                type: 'TEXT_DETECTION', // Better for sparse text
                maxResults: 1
              }
            ],
            imageContext: {
              languageHints: ['en', 'es'] // Added Spanish language support
            }
          }
        ]
      };

      const response = await fetch(VISION_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        throw new Error(`Google Vision API error: ${response.statusText}`);
      }

      const result = await response.json();
      
      // Check for errors in the response
      if (result.responses?.[0]?.error) {
        throw new Error(result.responses[0].error.message);
      }

      // Get text from both detection types and use the one with more content
      const docText = result.responses[0]?.fullTextAnnotation?.text || '';
      const textDetection = result.responses[0]?.textAnnotations?.[0]?.description || '';
      
      const text = docText.length > textDetection.length ? docText : textDetection;

      if (!text.trim()) {
        throw new Error('No text was detected in the image');
      }

      onCapture(text.trim());
      stopCamera();
      onClose();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to process image';
      setError(`Processing error: ${errorMessage}`);
      console.error('Error processing image:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const captureImage = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    setError(null);

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    if (!context) {
      setError('Failed to initialize canvas context');
      return;
    }

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw the current video frame
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Convert canvas to blob
    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(blob => {
        if (blob) resolve(blob);
        else reject(new Error('Failed to convert image'));
      }, 'image/jpeg', 0.9);
    });

    await processImage(blob);
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file');
      return;
    }

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError('Image size should be less than 10MB');
      return;
    }

    try {
      await processImage(file);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to process image';
      setError(`Upload error: ${errorMessage}`);
      console.error('Error processing uploaded image:', err);
    }
  };

  React.useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full overflow-hidden">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">Capture Note</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500 transition-colors duration-200"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="relative">
          {error ? (
            <div className="aspect-[4/3] bg-gray-100 flex items-center justify-center p-8">
              <div className="text-center">
                <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                <p className="text-red-600 mb-4">{error}</p>
                <button
                  onClick={() => {
                    setError(null);
                    startCamera();
                  }}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium 
                    rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 
                    focus:ring-offset-2 focus:ring-red-500 transition-all duration-200"
                >
                  Try Again
                </button>
              </div>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full aspect-[4/3] bg-black"
              />
              <canvas
                ref={canvasRef}
                className="hidden"
              />
            </>
          )}

          {isProcessing && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col items-center justify-center">
              <div className="text-white mb-4">Processing image...</div>
              <div className="animate-pulse text-white text-sm">This may take a few seconds...</div>
            </div>
          )}
        </div>

        <div className="p-4 flex justify-center gap-4">
          <button
            onClick={captureImage}
            disabled={isProcessing || !!error}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md
              text-white bg-gray-900 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2
              focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          >
            <Camera className="w-5 h-5 mr-2" />
            Capture
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
          
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isProcessing}
            className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md
              text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2
              focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          >
            <Upload className="w-5 h-5 mr-2" />
            Upload
          </button>
        </div>
      </div>
    </div>
  );
}