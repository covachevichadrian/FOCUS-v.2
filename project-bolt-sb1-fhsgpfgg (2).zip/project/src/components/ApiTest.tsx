import React, { useState } from 'react';
import { callOpenAI } from '../lib/openai';

export function ApiTest() {
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const testApi = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await callOpenAI(
        'Genera una recomendación para alguien que quiere desarrollar el hábito de correr. Responde en formato JSON con esta estructura: {"recommendation": {"title": "título corto", "description": "descripción detallada"}}',
        'Eres un asistente experto en desarrollo de hábitos saludables.'
      );
      setResponse(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-8">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">DeepSeek API Test</h2>
        
        <button
          onClick={testApi}
          disabled={loading}
          className="px-4 py-2 bg-gray-900 text-white rounded-md hover:bg-gray-800 
            disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
        >
          {loading ? 'Testing...' : 'Test API'}
        </button>

        {error && (
          <div className="mt-4 p-4 bg-red-50 text-red-600 rounded-md">
            {error}
          </div>
        )}

        {response && (
          <div className="mt-4">
            <h3 className="font-medium text-gray-900 mb-2">API Response:</h3>
            <pre className="p-4 bg-gray-50 rounded-md overflow-auto text-sm">
              {response}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}