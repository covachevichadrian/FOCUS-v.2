import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { LogOut, Home, CheckSquare, ListTodo, StickyNote, Target } from 'lucide-react';
import { format } from 'date-fns';

export function Layout() {
  const { signOut } = useAuthStore();
  const location = useLocation();
  const [currentTime, setCurrentTime] = React.useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const navigation = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Habits', href: '/habits', icon: CheckSquare },
    { name: 'Tasks', href: '/todos', icon: ListTodo },
    { name: 'Notes', href: '/notes', icon: StickyNote },
  ];

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col">
      {/* Header */}
      <header className="bg-white/5 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="text-blue-200 text-sm">
            {format(currentTime, 'EEEE, MMM d')}
          </div>
          <h1 className="text-2xl font-bold text-white">FOCUS</h1>
          <div className="text-blue-200 text-sm tabular-nums">
            {format(currentTime, 'h:mm a')}
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 relative">
        <Outlet />
      </main>

      {/* Footer navigation */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white/5 backdrop-blur-lg border-t border-white/10 z-50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-around">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex flex-col items-center py-3 px-4 text-sm font-medium transition-all duration-200
                    ${isActive
                      ? 'text-blue-400   '
                      : 'text-gray-400  hover:text-blue-400  hover:-translate-y-2'
                    }`}
                >
                  <Icon className={`w-6 h-6 mb-1 ${isActive ? 'text-blue-400' : 'text-gray-400'}`} />
                  <span className="text-xs">{item.name}</span>
                </Link>
              );
            })}
            {/* Goal Button (Centered and Larger) */}
            <Link
              to="/goals"
              className={`flex flex-col items-center py-3 px-4 text-sm font-medium transition-all duration-200
                ${location.pathname.startsWith('/goals')
                  ? 'text-blue-400 '
                  : 'text-gray-400 hover:text-blue-400 hover:-translate-y-2'
                }`}
            >
              <div className="relative">
                <div className="absolute inset-0 bg-blue-500/20 blur-lg rounded-full" />
                <div className={`relative mt-2 flex items-center justify-center rounded-full border-2
                  ${location.pathname.startsWith('/goals')
                    ? 'border-blue-400 bg-blue-500/20'
                    : 'border-gray-400 bg-gray-500/20 '
                  }`}
                >
                  <Target className="w-6 h-6" />
                </div>
              </div>
              <span className="text-xs mt-1">Goals</span>
            </Link>
            <button
              onClick={() => signOut()}
              className="flex flex-col items-center py-3 px-4 text-sm font-medium text-gray-400 hover:text-blue-400 hover:-translate-y-2 transition-all duration-200"
            >
              <LogOut className="w-6 h-6 mb-1" />
              <span className="text-xs">Logout</span>
            </button>
          </div>
        </nav>
      </footer>
    </div>
  );
}