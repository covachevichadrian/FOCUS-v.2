import React, { useState } from 'react';
import { Plus, Trash2, CheckCircle, Circle, GripVertical } from 'lucide-react';
import { useHabitStore, type Habit } from '../store/habitStore';
import { getLastNDays } from '../lib/utils';
import { useNavigate } from 'react-router-dom';

const WEEKDAYS = [
  { value: 0, label: 'D' },
  { value: 1, label: 'L' },
  { value: 2, label: 'M' },
  { value: 3, label: 'X' },
  { value: 4, label: 'J' },
  { value: 5, label: 'V' },
  { value: 6, label: 'S' },
];

type AnimatingHabit = {
  habitId: string;
  date: string;
};

export function HabitList() {
  const navigate = useNavigate();
  const [newHabitName, setNewHabitName] = useState('');
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [showDaySelector, setShowDaySelector] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [lastClickedHabit, setLastClickedHabit] = useState<string | null>(null);
  const [animatingHabits, setAnimatingHabits] = useState<AnimatingHabit[]>([]);
  
  const { habits, completions, createHabit, deleteHabit, toggleHabitCompletion } = useHabitStore();
  const dates = getLastNDays(7);

  const handleCreateHabit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim() || selectedDays.length === 0) return;
    
    try {
      await createHabit(newHabitName, selectedDays);
      setNewHabitName('');
      setSelectedDays([]);
      setShowDaySelector(false);
    } catch (error) {
      console.error('Failed to create habit:', error);
    }
  };

  const toggleDay = (day: number) => {
    setSelectedDays(prev => {
      if (prev.includes(day)) {
        if (prev.length === 1) return prev;
        return prev.filter(d => d !== day);
      }
      return [...prev, day].sort();
    });
  };

  const isCompleted = (habit: Habit, date: Date) => {
    const dayOfWeek = date.getDay();
    if (!habit.active_days.includes(dayOfWeek)) return null;

    return completions.some(completion => 
      completion.habit_id === habit.id && 
      completion.completed_at.startsWith(date.toISOString().split('T')[0])
    );
  };

  const checkWeekCompletion = (habit: Habit) => {
    return dates.every(date => {
      const dayOfWeek = date.getDay();
      if (!habit.active_days.includes(dayOfWeek)) return true;
      return isCompleted(habit, date);
    });
  };

  const isAnimating = (habitId: string, date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return animatingHabits.some(
      ah => ah.habitId === habitId && ah.date === dateStr
    );
  };

  const handleToggleHabit = async (habitId: string, date: Date) => {
    const habit = habits.find(h => h.id === habitId);
    if (!habit) return;

    const dayOfWeek = date.getDay();
    if (!habit.active_days.includes(dayOfWeek)) return;

    const dateStr = date.toISOString().split('T')[0];

    setAnimatingHabits(prev => [...prev, { habitId, date: dateStr }]);

    await toggleHabitCompletion(habitId, date);
    setLastClickedHabit(habitId);

    setTimeout(() => {
      setAnimatingHabits(prev => 
        prev.filter(ah => !(ah.habitId === habitId && ah.date === dateStr))
      );
    }, 300);
  };

  React.useEffect(() => {
    if (!lastClickedHabit) return;

    const habit = habits.find(h => h.id === lastClickedHabit);
    if (!habit) return;

    const isCompleted = checkWeekCompletion(habit);
    if (isCompleted) {
      setShowCelebration(true);
      setTimeout(() => {
        setShowCelebration(false);
      }, 3000);
    }

    setLastClickedHabit(null);
  }, [completions, habits, lastClickedHabit]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-blue-950 text-white p-4 sm:p-8">
      <div className="max-w-7xl mx-auto pb-24">
        <form onSubmit={handleCreateHabit} className="mb-8">
          <div className="relative">
            <input
              type="text"
              value={newHabitName}
              onChange={(e) => setNewHabitName(e.target.value)}
              onFocus={() => setShowDaySelector(true)}
              placeholder="New habit..."
              className="w-full pl-4 pr-12 py-3 bg-white/5 border border-white/10 rounded-lg 
                text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                transition-all duration-200"
            />
            <button
              type="submit"
              disabled={selectedDays.length === 0}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-500 text-white rounded-lg 
                hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                focus:ring-offset-gray-900 disabled:opacity-50 disabled:cursor-not-allowed
                transition-all duration-200"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>

          {showDaySelector && (
            <div className="animate-fade-in mt-4">
              <label className="block text-sm font-medium text-blue-200 mb-2">
                Active days
              </label>
              <div className="flex gap-2 flex-wrap">
                {WEEKDAYS.map(day => (
                  <button
                    key={day.value}
                    type="button"
                    onClick={() => toggleDay(day.value)}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium
                      transition-all duration-200 ${
                      selectedDays.includes(day.value)
                        ? 'bg-blue-500 text-white'
                        : 'bg-white/5 text-blue-200 hover:bg-white/10'
                    }`}
                  >
                    {day.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </form>

        {/* Mobile view */}
        <div className="lg:hidden space-y-2">
          {habits.map(habit => (
            <div 
              key={habit.id}
              className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-lg overflow-hidden"
            >
              <div 
                onClick={() => navigate(`/habits/${habit.id}`)}
                className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-white/5 transition-colors duration-200"
              >
                <div className="flex items-center gap-2">
                  <span className="text-base font-medium text-white hover:text-blue-200 transition-colors duration-200 line-clamp-1">
                    {habit.name}
                  </span>
                </div>
                
              </div>

              <div className="grid grid-cols-7 divide-x divide-white/10">
                {dates.map(date => {
                  const completed = isCompleted(habit, date);
                  const dayOfWeek = date.getDay();
                  const isActiveDay = habit.active_days.includes(dayOfWeek);
                  const weekday = WEEKDAYS[dayOfWeek].label;
                  const isCurrentlyAnimating = isAnimating(habit.id, date);

                  return (
                    <div
                      key={date.toISOString()}
                      className="flex flex-col items-center py-2"
                    >
                      <div className="text-xs text-blue-200/60 h-4 flex items-center mb-1">
                        {weekday}
                      </div>
                      <div className="relative w-full aspect-square flex justify-center">
                        <button
                          onClick={() => handleToggleHabit(habit.id, date)}
                          disabled={!isActiveDay}
                          className={`habit-button w-full h-full flex items-center justify-center relative
                            ${!isActiveDay ? 'opacity-50 cursor-not-allowed' : ''}`}
                        >
                          {isActiveDay && (
                            <>
                              {!completed && (
                                <Circle className="w-5 h-5 text-white/30" />
                              )}
                              {completed && (
                                <div className={`absolute inset-0 flex items-center justify-center ${isCurrentlyAnimating ? 'habit-check-animation' : ''}`}>
                                  <CheckCircle className="w-5 h-5 text-blue-400" />
                                </div>
                              )}
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Desktop view */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full border-separate border-spacing-y-2">
            <thead>
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-blue-200/60 uppercase tracking-wider w-64">
                  Habit
                </th>
                {dates.map(date => {
                  const weekday = WEEKDAYS[date.getDay()].label;
                  return (
                    <th
                      key={date.toISOString()}
                      className="px-6 py-3 text-center text-xs font-medium text-blue-200/60 uppercase tracking-wider"
                    >
                      {weekday}
                    </th>
                  );
                })}
                <th className="px-6 py-3 text-center text-xs font-medium text-blue-200/60 uppercase tracking-wider">
                  Streak
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-blue-200/60 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="relative">
              {habits.map(habit => (
                <tr 
                  key={habit.id} 
                  className="bg-white/5 backdrop-blur-lg transition-all duration-200 group"
                >
                  <td 
                    onClick={() => navigate(`/habits/${habit.id}`)}
                    className="px-6 py-6 whitespace-nowrap text-sm font-medium text-white rounded-l-lg border border-white/10 
                      group-hover:border-white/20 cursor-pointer hover:bg-white/5 transition-all duration-200 
                      relative hover:z-20 hover:scale-[1.02]"
                    style={{ transformOrigin: 'center left' }}
                  >
                    {habit.name}
                  </td>
                  {dates.map(date => {
                    const completed = isCompleted(habit, date);
                    const dayOfWeek = date.getDay();
                    const isActiveDay = habit.active_days.includes(dayOfWeek);
                    const isCurrentlyAnimating = isAnimating(habit.id, date);

                    return (
                      <td
                        key={date.toISOString()}
                        className="px-6 py-6 whitespace-nowrap text-sm text-gray-500 text-center border-t border-b border-white/10 
                          group-hover:border-white/20 relative"
                      >
                        <div className="flex items-center justify-center">
                          <div className="relative w-8 h-8">
                            <button
                              onClick={() => handleToggleHabit(habit.id, date)}
                              disabled={!isActiveDay}
                              className={`habit-button w-full h-full rounded-full transform transition-all duration-200
                                ${!isActiveDay
                                  ? 'cursor-not-allowed opacity-50'
                                  : completed
                                    ? 'bg-blue-500/20 hover:bg-blue-500/30 hover:scale-105'
                                    : 'bg-white/5 border border-white/10 hover:border-white/20 hover:scale-105'
                                }`}
                            >
                              {isActiveDay && (
                                <>
                                  {!completed && (
                                    <Circle className="w-5 h-5 text-white/30" />
                                  )}
                                  <div className={`habit-icon completed ${completed ? 'visible' : ''} ${isCurrentlyAnimating ? 'habit-check-animation' : ''} absolute inset-0`}>
                                    {completed && (
                                      <CheckCircle className="w-5 h-5 text-blue-400" />
                                    )}
                                  </div>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      </td>
                    );
                  })}
                  <td className="px-6 py-6 whitespace-nowrap text-sm text-center font-semibold border-t border-b border-white/10 group-hover:border-white/20 text-blue-400">
                    {habit.streak}
                  </td>
                  <td className="px-6 py-6 whitespace-nowrap text-right text-sm font-medium rounded-r-lg border border-white/10 group-hover:border-white/20">
                    <button
                      onClick={() => deleteHabit(habit.id)}
                      className="text-white/40 hover:text-white/60 transition-colors duration-200 opacity-0 group-hover:opacity-100 
                        transform hover:scale-105"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showCelebration && (
          <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none px-4">
            <div className="celebration-container max-w-sm w-full">
              <div className="celebration-icon text-yellow-500 text-4xl mb-4">
                🎉
              </div>
              <h3 className="celebration-text text-2xl font-bold text-yellow-600 mb-2">
                Congratulations!
              </h3>
              <p className="text-blue-200">
                You've completed all active days for this habit.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}