import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { useHabitStore } from '../store/habitStore';
import { useTodoStore } from '../store/todoStore';
import { useNoteStore } from '../store/noteStore';
import { Circle, CheckCircle, ArrowRight, Clock, Calendar } from 'lucide-react';
import { useQuote } from '../lib/quotes';

interface EditState {
  title: string;
  description: string;
  reminderDate: string;
  reminderTime: string;
}

export function Dashboard() {
  const { quote } = useQuote();
  const [completingTodoId, setCompletingTodoId] = useState<string | null>(null);
  const [completingHabitId, setCompletingHabitId] = useState<string | null>(null);
  const [editingTodoId, setEditingTodoId] = useState<string | null>(null);
  const [editStates, setEditStates] = useState<Record<string, EditState>>({});
  
  const editRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLInputElement>(null);
  
  const { habits, completions, toggleHabitCompletion } = useHabitStore();
  const { todos, toggleTodo, updateTodo, updateReminder } = useTodoStore();
  const { notes } = useNoteStore();

  // Filter habits for today
  const today = new Date();
  const todayDayOfWeek = today.getDay();
  const todaysHabits = habits.filter(habit => 
    habit.active_days.includes(todayDayOfWeek)
  );

  useEffect(() => {
    const newEditStates: Record<string, EditState> = {};
    todos.forEach(todo => {
      newEditStates[todo.id] = {
        title: todo.title,
        description: todo.description || '',
        reminderDate: todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : '',
        reminderTime: todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : ''
      };
    });
    setEditStates(newEditStates);
  }, [todos]);

  useEffect(() => {
    if (editingTodoId && titleRef.current) {
      titleRef.current.focus();
    }
  }, [editingTodoId]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (editingTodoId && editRef.current && !editRef.current.contains(event.target as Node)) {
        handleSave(editingTodoId);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [editingTodoId]);

  const isCompleted = (habitId: string) => {
    return completions.some(completion => 
      completion.habit_id === habitId && 
      completion.completed_at.startsWith(today.toISOString().split('T')[0])
    );
  };

  const activeTodos = todos
    .filter(todo => !todo.completed)
    .sort((a, b) => {
      if (a.reminder_at && !b.reminder_at) return -1;
      if (!a.reminder_at && b.reminder_at) return 1;
      if (a.reminder_at && b.reminder_at) {
        return new Date(a.reminder_at).getTime() - new Date(b.reminder_at).getTime();
      }
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    })
    .slice(0, 3);

  const recentNotes = notes
    .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
    .slice(0, 3);

  const handleToggleTodo = async (id: string) => {
    setCompletingTodoId(id);
    setTimeout(async () => {
      await toggleTodo(id);
      setCompletingTodoId(null);
    }, 800);
  };

  const handleToggleHabit = async (habitId: string) => {
    if (completingHabitId) return; // Prevent multiple animations at once
    
    const wasCompleted = isCompleted(habitId);
    if (!wasCompleted) {
      setCompletingHabitId(habitId);
      setTimeout(() => {
        setCompletingHabitId(null);
      }, 500); // Match the animation duration
    }
    
    await toggleHabitCompletion(habitId, today);
  };

  const handleEditChange = (todoId: string, field: keyof EditState, value: string) => {
    setEditStates(prev => ({
      ...prev,
      [todoId]: {
        ...prev[todoId],
        [field]: value
      }
    }));
  };

  const handleSave = async (todoId: string) => {
    const editState = editStates[todoId];
    if (!editState.title.trim()) {
      setEditingTodoId(null);
      const todo = todos.find(t => t.id === todoId);
      if (todo) {
        setEditStates(prev => ({
          ...prev,
          [todoId]: {
            title: todo.title,
            description: todo.description || '',
            reminderDate: todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : '',
            reminderTime: todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : ''
          }
        }));
      }
      return;
    }

    let reminderAt: Date | null = null;
    if (editState.reminderDate && editState.reminderTime) {
      reminderAt = new Date(`${editState.reminderDate}T${editState.reminderTime}`);
    }

    await updateTodo(todoId, editState.title.trim(), editState.description.trim() || undefined);
    await updateReminder(todoId, reminderAt);
    setEditingTodoId(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent, todoId: string) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSave(todoId);
    } else if (e.key === 'Escape') {
      setEditingTodoId(null);
      const todo = todos.find(t => t.id === todoId);
      if (todo) {
        setEditStates(prev => ({
          ...prev,
          [todoId]: {
            title: todo.title,
            description: todo.description || '',
            reminderDate: todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : '',
            reminderTime: todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : ''
          }
        }));
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
      {/* Quote */}
      <div className="bg-gradient-to-br from-black via-gray-900 to-blue-950 text-white rounded-lg shadow-lg p-8 mb-8 transform transition-all duration-500 hover:scale-[1.02] hover:shadow-xl">
        <blockquote className="text-xl italic">
          "{quote.q}"
        </blockquote>
        <p className="mt-4 text-blue-300">— {quote.a}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-8">
          {/* Today's Habits */}
          <div className="bg-white/5 backdrop-blur-lg border-t border-white/10 rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-100">Today's Habits</h2>
              <Link to="/habits" className="text-gray-100 hover:text-gray-200 flex items-center gap-2 group">
                View all
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
            </div>
            <ul className="space-y-4">
              {todaysHabits.map(habit => {
                const completed = isCompleted(habit.id);
                const isCompleting = completingHabitId === habit.id;
                
                return (
                  <li 
                    key={habit.id}
                    className={`habit-item flex items-center justify-between p-4 rounded-lg 
                      transition-all duration-200 group cursor-pointer
                      ${completed ? 'bg-green-900/70' : 'bg-white/90 hover:bg-gray-100'}
                      ${isCompleting ? 'completing' : ''}`}
                    onClick={() => handleToggleHabit(habit.id)}
                  >
                    <span className={`${completed ? 'text-white' : 'text-gray-900'}`}>
                      {habit.name}
                    </span>
                    <div className="flex items-center gap-4">
                      <span className={`habit-streak text-sm ${
                        completed ? 'text-green-100' : 'text-gray-500'
                      }`}>
                        Streak: {habit.streak}
                      </span>
                      <div className={`habit-icon transition-colors duration-200 ${
                        completed 
                          ? 'text-white' 
                          : 'text-gray-400 group-hover:text-gray-800'
                      }`}>
                        {completed ? (
                          <CheckCircle className="w-6 h-6" />
                        ) : (
                          <Circle className="w-6 h-6" />
                        )}
                      </div>
                    </div>
                  </li>
                );
              })}
              {todaysHabits.length === 0 && (
                <p className="text-gray-500 text-center py-4">No habits scheduled for today</p>
              )}
            </ul>
          </div>

          {/* Tasks */}
          <div className="bg-white/5 backdrop-blur-lg border-t border-white/10 rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-100">Tasks</h2>
              <Link to="/todos" className="text-gray-100 hover:text-gray-200 flex items-center gap-2 group">
                View all
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
            </div>
            <ul className="space-y-4">
              {activeTodos.map(todo => {
                const isEditing = editingTodoId === todo.id;
                const editState = editStates[todo.id];
                const isCompleting = completingTodoId === todo.id;

                return (
                  <li 
                    key={todo.id}
                    className={`todo-item p-4 rounded-lg bg-white/90 hover:bg-gray-100 
                      hover:shadow-md hover:-translate-y-0.5 group relative
                      ${isCompleting ? 'completing' : ''}`}
                  >
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => handleToggleTodo(todo.id)}
                        className="mt-1 transition-all duration-300 ease-in-out transform
                          text-gray-400 hover:text-gray-800 hover:scale-110 active:scale-95"
                      >
                        <Circle className="w-5 h-5" />
                      </button>
                      
                      <div 
                        ref={isEditing ? editRef : null}
                        className="flex-1 min-w-0 cursor-pointer"
                        onClick={() => !isEditing && setEditingTodoId(todo.id)}
                      >
                        {isEditing && editState ? (
                          <div className="space-y-4">
                            <input
                              ref={titleRef}
                              type="text"
                              value={editState.title}
                              onChange={(e) => handleEditChange(todo.id, 'title', e.target.value)}
                              onKeyDown={(e) => handleKeyDown(e, todo.id)}
                              className="w-full px-3 py-2 text-gray-700 bg-white border border-gray-200 rounded-md 
                                focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-gray-400
                                transition-all duration-200"
                              placeholder="Task title"
                            />
                            <textarea
                              value={editState.description}
                              onChange={(e) => handleEditChange(todo.id, 'description', e.target.value)}
                              onKeyDown={(e) => handleKeyDown(e, todo.id)}
                              className="w-full px-3 py-2 text-gray-700 bg-white border border-gray-200 rounded-md 
                                focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-gray-400
                                transition-all duration-200 "
                              placeholder="Add a description (optional)"
                            />
                            <div className="flex gap-4">
                              <div className="flex-1">
                                <label className="block text-sm font-medium text-gray-600 mb-1">
                                  Date
                                </label>
                                <input
                                  type="date"
                                  value={editState.reminderDate}
                                  onChange={(e) => handleEditChange(todo.id, 'reminderDate', e.target.value)}
                                  className="w-full px-3 py-2 text-gray-700 bg-white border border-gray-200 rounded-md 
                                    focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-gray-400
                                    transition-all duration-200"
                                />
                              </div>
                              <div className="flex-1">
                                <label className="block text-sm font-medium text-gray-600 mb-1">
                                  Time
                                </label>
                                <input
                                  type="time"
                                  value={editState.reminderTime}
                                  onChange={(e) => handleEditChange(todo.id, 'reminderTime', e.target.value)}
                                  className="w-full px-3 py-2 text-gray-700 bg-white border border-gray-200 rounded-md 
                                    focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-gray-400
                                    transition-all duration-200"
                                />
                              </div>
                            </div>
                            <div className="flex justify-end gap-2">
                              <button
                                onClick={() => {
                                  setEditingTodoId(null);
                                  setEditStates(prev => ({
                                    ...prev,
                                    [todo.id]: {
                                      title: todo.title,
                                      description: todo.description || '',
                                      reminderDate: todo.reminder_at ? format(new Date(todo.reminder_at), 'yyyy-MM-dd') : '',
                                      reminderTime: todo.reminder_at ? format(new Date(todo.reminder_at), 'HH:mm') : ''
                                    }
                                  }));
                                }}
                                className="px-3 py-1 text-sm text-gray-600 hover:text-gray-900 
                                  transition-colors duration-200"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={() => handleSave(todo.id)}
                                className="mx-2 px-3 py-1 text-sm bg-gray-900 text-white rounded-md 
                                  hover:bg-gray-800 transition-colors duration-200"
                              >
                                Save
                              </button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <h3 className="font-medium text-gray-900">
                              {todo.title}
                            </h3>
                            {todo.description && (
                              <p className="mt-1 text-sm text-gray-600">
                                {todo.description}
                              </p>
                            )}
                            <div className="mt-2 flex items-center gap-1 text-xs text-gray-500">
                              {todo.reminder_at ? (
                                <>
                                  <Clock className="w-4 h-4" />
                                  <span>Due {format(new Date(todo.reminder_at), 'MMM d, h:mm a')}</span>
                                </>
                              ) : (
                                <>
                                  <Calendar className="w-4 h-4" />
                                  <span>Add reminder</span>
                                </>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    {isCompleting && (
                      <div className="checkmark">
                        <CheckCircle className="w-12 h-12 text-green-500" />
                      </div>
                    )}
                  </li>
                );
              })}
              {activeTodos.length === 0 && (
                <p className="text-gray-500 text-center py-4">No active tasks</p>
              )}
            </ul>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-8">
          {/* Recent Notes */}
          <div className="bg-white/5 backdrop-blur-lg border-t border-white/10 rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-100">Recent Notes</h2>
              <Link to="/notes" className="text-gray-100 hover:text-gray-200 flex items-center gap-2 group">
                View all
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
            </div>
            <ul className="space-y-4">
              {recentNotes.map(note => (
                <li 
                  key={note.id}
                  className="p-4 bg-white/90 rounded-lg hover:bg-gray-100 transition-colors duration-200"
                >
                  <h3 className="font-medium text-gray-900">{note.title}</h3>
                  {note.content && (
                    <p className="mt-1 text-sm text-gray-600 line-clamp-2">{note.content}</p>
                  )}
                  <p className="mt-2 text-xs text-gray-500">
                    Updated {format(new Date(note.updated_at), 'MMM d, h:mm a')}
                  </p>
                </li>
              ))}
              {recentNotes.length === 0 && (
                <p className="text-gray-500 text-center py-4">No notes yet</p>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}