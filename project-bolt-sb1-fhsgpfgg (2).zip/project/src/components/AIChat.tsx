import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Bot, User, MessageSquare } from 'lucide-react';
import { useHabitStore } from '../store/habitStore';
import { useTodoStore } from '../store/todoStore';
import { useNoteStore } from '../store/noteStore';
import { callOpenAI } from '../lib/openai';
import { supabase } from '../lib/supabase';

interface Message {
  id?: string;
  role: 'user' | 'assistant';
  content: string;
  created_at?: string;
}

interface Props {
  goal: {
    id: string;
    title: string;
    description: string;
  };
}

export function AIChat({ goal }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const { habits } = useHabitStore();
  const { todos } = useTodoStore();
  const { notes } = useNoteStore();

  useEffect(() => {
    const loadChatHistory = async () => {
      try {
        const { data, error } = await supabase
          .from('goal_chat_history')
          .select('*')
          .eq('goal_id', goal.id)
          .order('created_at', { ascending: true });

        if (error) throw error;
        setMessages(data || []);
      } catch (err) {
        console.error('Error loading chat history:', err);
      } finally {
        setIsLoadingHistory(false);
      }
    };

    loadChatHistory();
  }, [goal.id]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (showHistory) {
      scrollToBottom();
    }
  }, [messages, showHistory]);

  const saveMessage = async (message: Message) => {
    try {
      const { data, error } = await supabase
        .from('goal_chat_history')
        .insert({
          goal_id: goal.id,
          role: message.role,
          content: message.content
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (err) {
      console.error('Error saving message:', err);
      throw err;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setShowHistory(true);
    
    try {
      const savedUserMessage = await saveMessage({
        role: 'user',
        content: userMessage
      });
      setMessages(prev => [...prev, savedUserMessage]);
      setIsLoading(true);

      const context = `
Goal: ${goal.title}
Description: ${goal.description}

Current Habits:
${habits.map(h => `- ${h.name} (Streak: ${h.streak} days)`).join('\n')}

Active Tasks:
${todos.filter(t => !t.completed).map(t => `- ${t.title}`).join('\n')}

Recent Notes:
${notes.map(n => `- ${n.title}`).join('\n')}
`;

      const prompt = `
Context about the user:
${context}

User's question:
${userMessage}

Please provide a helpful response considering the user's goal, habits, tasks, and notes. Focus on actionable advice that aligns with their objectives. Format your response as a json object with a 'message' field containing your response.`;

      const response = await callOpenAI(
        prompt,
        'You are a helpful AI assistant focused on personal development and goal achievement. Your responses should be practical, motivating, and aligned with the user\'s objectives.'
      );

      const parsedResponse = JSON.parse(response);
      const messageContent = parsedResponse.message;

      const savedAIMessage = await saveMessage({
        role: 'assistant',
        content: messageContent
      });
      setMessages(prev => [...prev, savedAIMessage]);
    } catch (error) {
      console.error('Error in chat interaction:', error);
      const errorMessage = {
        role: 'assistant' as const,
        content: 'I apologize, but I encountered an error processing your request. Please try again.'
      };
      
      const savedErrorMessage = await saveMessage(errorMessage);
      setMessages(prev => [...prev, savedErrorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      handleSubmit(e);
    }
  };

  const adjustTextareaHeight = () => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = `${inputRef.current.scrollHeight}px`;
    }
  };

  if (isLoadingHistory) {
    return (
      <div className="flex flex-col h-[600px] bg-white/5 backdrop-blur-lg rounded-lg border border-white/10 items-center justify-center">
        <Loader2 className="w-8 h-8 text-blue-400 animate-spin" />
        <p className="mt-4 text-gray-400">Loading chat history...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col bg-white/5 backdrop-blur-lg rounded-lg border border-white/10">
      <div 
        className={`overflow-y-auto p-4 space-y-4 transition-all duration-300 ease-in-out ${
          showHistory ? 'h-[500px] opacity-100' : 'h-0 opacity-0'
        }`}
      >
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <MessageSquare className="w-16 h-16 text-gray-500 mb-4" />
            <h3 className="text-xl font-semibold text-gray-400 mb-2">
              Start a Conversation
            </h3>
            <p className="text-gray-500 max-w-sm">
              Ask me anything about your goal. I'm here to help you stay focused and achieve your objectives.
            </p>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${
                message.role === 'assistant' ? 'bg-white/5' : ''
              } rounded-lg p-4`}
            >
              <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center
                ${message.role === 'assistant' ? 'bg-blue-500/20' : 'bg-purple-500/20'}`}
              >
                {message.role === 'assistant' ? (
                  <Bot className="w-5 h-5 text-blue-400" />
                ) : (
                  <User className="w-5 h-5 text-purple-400" />
                )}
              </div>
              <div className="flex-1 text-gray-100 whitespace-pre-wrap">
                {message.content}
              </div>
            </div>
          ))
        )}
        {isLoading && (
          <div className="flex gap-3 bg-white/5 rounded-lg p-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
              <Bot className="w-5 h-5 text-blue-400" />
            </div>
            <div className="flex-1">
              <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t border-white/10">
        <div className="relative">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              adjustTextareaHeight();
            }}
            onFocus={() => setShowHistory(true)}
            onKeyDown={handleKeyDown}
            placeholder="Ask anything about your goal..."
            className="w-full pr-12 pl-4 py-3 bg-white/5 border border-white/10 rounded-lg 
              text-gray-100 placeholder-gray-400 focus:outline-none focus:border-blue-500/40
              transition-all duration-200 resize-none overflow-hidden"
            rows={1}
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gray-400 
              hover:text-gray-100 disabled:opacity-50 disabled:cursor-not-allowed
              transition-colors duration-200"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
        <div className="mt-2 text-xs text-gray-500 text-right">
          Press {navigator.platform.includes('Mac') ? '⌘' : 'Ctrl'} + Enter to send
        </div>
      </form>
    </div>
  );
}