import React, { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { Mail, Lock, Loader2, AlertCircle, ArrowRight, CheckCircle } from 'lucide-react';

type AuthMode = 'signIn' | 'signUp' | 'confirmEmail' | 'resetPassword' | 'updatePassword';

export function Auth() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [mode, setMode] = useState<AuthMode>('signIn');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [confirmationSent, setConfirmationSent] = useState(false);
  const { signIn, signUp, resetPassword, updatePassword } = useAuthStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      if (mode === 'signUp') {
        if (password !== confirmPassword) {
          throw new Error('Las contraseñas no coinciden');
        }
        if (password.length < 8) {
          throw new Error('La contraseña debe tener al menos 8 caracteres');
        }
        const { confirmationSent } = await signUp(email, password);
        if (confirmationSent) {
          setConfirmationSent(true);
          setMode('confirmEmail');
        }
      } else if (mode === 'signIn') {
        await signIn(email, password);
      } else if (mode === 'resetPassword') {
        await resetPassword(email);
        setConfirmationSent(true);
      } else if (mode === 'updatePassword') {
        if (password !== confirmPassword) {
          throw new Error('Las contraseñas no coinciden');
        }
        await updatePassword(password);
        setMode('signIn');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ha ocurrido un error');
    } finally {
      setLoading(false);
    }
  };

  const handleResendConfirmation = async () => {
    setError('');
    setLoading(true);
    
    try {
      await useAuthStore.getState().resendConfirmation(email);
      setConfirmationSent(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al reenviar el correo');
    } finally {
      setLoading(false);
    }
  };

  if (mode === 'confirmEmail') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-blue-950 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="text-center">
            <CheckCircle className="mx-auto h-12 w-12 text-blue-500" />
            <h2 className="mt-6 text-3xl font-extrabold text-white">
              Verifica tu correo
            </h2>
            <p className="mt-2 text-sm text-blue-200">
              Te hemos enviado un correo de confirmación a {email}
            </p>
          </div>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white/5 backdrop-blur-lg py-8 px-4 shadow-lg rounded-lg border border-white/10 sm:px-10">
            <div className="space-y-6">
              <p className="text-sm text-blue-200/80 text-center">
                Por favor, revisa tu bandeja de entrada y sigue las instrucciones para confirmar tu cuenta.
              </p>

              {error && (
                <div className="rounded-lg bg-red-500/10 border border-red-500/20 p-4">
                  <div className="flex">
                    <AlertCircle className="h-5 w-5 text-red-400" />
                    <div className="ml-3">
                      <p className="text-sm text-red-400">{error}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-col space-y-4">
                <button
                  onClick={handleResendConfirmation}
                  disabled={loading || confirmationSent}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : confirmationSent ? (
                    'Correo reenviado'
                  ) : (
                    'Reenviar correo de confirmación'
                  )}
                </button>

                <button
                  onClick={() => {
                    setMode('signIn');
                    setError('');
                    setConfirmationSent(false);
                  }}
                  className="text-sm text-blue-200 hover:text-white transition-colors duration-200"
                >
                  Volver al inicio de sesión
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-blue-950 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="text-center text-3xl font-extrabold text-white">
          {mode === 'signIn' && 'Iniciar sesión'}
          {mode === 'signUp' && 'Crear cuenta'}
          {mode === 'resetPassword' && 'Restablecer contraseña'}
          {mode === 'updatePassword' && 'Actualizar contraseña'}
        </h2>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white/5 backdrop-blur-lg py-8 px-4 shadow-lg rounded-lg border border-white/10 sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {(mode === 'signIn' || mode === 'signUp' || mode === 'resetPassword') && (
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-blue-200 mb-1">
                  Correo electrónico
                </label>
                <div className="mt-1 relative">
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 pl-10 bg-white/5 border border-white/10 rounded-lg text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40 transition-all duration-200"
                  />
                  <Mail className="absolute left-3 top-2.5 h-5 w-5 text-blue-200/60" />
                </div>
              </div>
            )}

            {(mode === 'signIn' || mode === 'signUp' || mode === 'updatePassword') && (
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-blue-200 mb-1">
                  Contraseña
                </label>
                <div className="mt-1 relative">
                  <input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete={mode === 'signUp' ? 'new-password' : 'current-password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 pl-10 bg-white/5 border border-white/10 rounded-lg text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40 transition-all duration-200"
                  />
                  <Lock className="absolute left-3 top-2.5 h-5 w-5 text-blue-200/60" />
                </div>
              </div>
            )}

            {(mode === 'signUp' || mode === 'updatePassword') && (
              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-blue-200 mb-1">
                  Confirmar contraseña
                </label>
                <div className="mt-1 relative">
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    autoComplete="new-password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 pl-10 bg-white/5 border border-white/10 rounded-lg text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40 transition-all duration-200"
                  />
                  <Lock className="absolute left-3 top-2.5 h-5 w-5 text-blue-200/60" />
                </div>
              </div>
            )}

            {error && (
              <div className="rounded-lg bg-red-500/10 border border-red-500/20 p-4">
                <div className="flex">
                  <AlertCircle className="h-5 w-5 text-red-400" />
                  <div className="ml-3">
                    <p className="text-sm text-red-400">{error}</p>
                  </div>
                </div>
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center items-center gap-2 py-2 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    {mode === 'signIn' && 'Iniciar sesión'}
                    {mode === 'signUp' && 'Crear cuenta'}
                    {mode === 'resetPassword' && 'Enviar instrucciones'}
                    {mode === 'updatePassword' && 'Actualizar contraseña'}
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          <div className="mt-6 flex flex-col space-y-4">
            {mode === 'signIn' && (
              <>
                <button
                  onClick={() => {
                    setMode('signUp');
                    setError('');
                  }}
                  className="text-sm text-center text-blue-200 hover:text-white transition-colors duration-200"
                >
                  ¿No tienes una cuenta? Regístrate
                </button>
                <button
                  onClick={() => {
                    setMode('resetPassword');
                    setError('');
                  }}
                  className="text-sm text-center text-blue-200 hover:text-white transition-colors duration-200"
                >
                  ¿Olvidaste tu contraseña?
                </button>
              </>
            )}

            {(mode === 'signUp' || mode === 'resetPassword' || mode === 'updatePassword') && (
              <button
                onClick={() => {
                  setMode('signIn');
                  setError('');
                }}
                className="text-sm text-center text-blue-200 hover:text-white transition-colors duration-200"
              >
                Volver al inicio de sesión
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}