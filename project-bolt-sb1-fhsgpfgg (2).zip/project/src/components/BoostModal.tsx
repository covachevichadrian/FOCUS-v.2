import React, { useState } from 'react';
import { X, Loader2, Sparkles, Plus, CheckCircle } from 'lucide-react';
import { useHabitStore } from '../store/habitStore';
import { useTodoStore } from '../store/todoStore';
import { callOpenAI } from '../lib/openai';

interface Suggestion {
  type: 'habit' | 'todo';
  title: string;
  description: string;
  reason: string;
}

interface AIResponse {
  suggestions: Suggestion[];
}

interface Props {
  goal: {
    id: string;
    title: string;
    description: string;
  };
  onClose: () => void;
}

export function BoostModal({ goal, onClose }: Props) {
  const [isLoading, setIsLoading] = useState(true);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [selectedSuggestions, setSelectedSuggestions] = useState<Record<number, boolean>>({});
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { habits, createHabit } = useHabitStore();
  const { todos, createTodo } = useTodoStore();

  React.useEffect(() => {
    generateSuggestions();
  }, []);

  const generateSuggestions = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const context = `
Goal: "${goal.title}"
Description: ${goal.description}

Current Habits:
${habits.map(h => `- ${h.name} (Streak: ${h.streak} days)`).join('\n')}

Active Tasks:
${todos.filter(t => !t.completed).map(t => `- ${t.title}`).join('\n')}
`;

      const prompt = `Based on the user's goal and current habits/tasks, suggest 4 new items (2 habits and 2 tasks) that would help them achieve their goal faster.

Context:
${context}

Rules:
1. Suggest EXACTLY 2 new habits and 2 new tasks
2. Each suggestion must be:
   - Specific and actionable
   - Different from existing habits/tasks
   - Directly related to the goal
3. For each suggestion, explain WHY it would help achieve the goal

Format your response as a JSON object with this exact structure:
{
  "suggestions": [
    {
      "type": "habit",
      "title": "short, specific title",
      "description": "detailed description of how to implement",
      "reason": "explanation of how this helps achieve the goal"
    }
  ]
}`;

      const response = await callOpenAI(
        prompt,
        'You are an expert AI coach focused on helping users achieve their goals through actionable habits and tasks.'
      );

      const data = JSON.parse(response) as AIResponse;
      setSuggestions(data.suggestions);
    } catch (err) {
      console.error('Error generating suggestions:', err);
      setError(err instanceof Error ? err.message : 'Error generating suggestions');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreate = async () => {
    try {
      setCreating(true);
      setError(null);

      const selectedItems = suggestions.filter((_, index) => selectedSuggestions[index]);
      
      for (const item of selectedItems) {
        if (item.type === 'habit') {
          await createHabit(item.title, [0, 1, 2, 3, 4, 5, 6]);
        } else {
          await createTodo(item.title, item.description);
        }
      }

      onClose();
    } catch (err) {
      console.error('Error creating items:', err);
      setError(err instanceof Error ? err.message : 'Error creating items');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-hidden border border-white/10 my-8">
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-gray-900 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-semibold text-white">AI Boost</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto" style={{ maxHeight: 'calc(90vh - 180px)' }}>
          <div className="p-6">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-blue-400 animate-spin mb-4" />
                <p className="text-gray-400">Generating personalized suggestions...</p>
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <p className="text-red-400 mb-4">{error}</p>
                <button
                  onClick={generateSuggestions}
                  className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Try Again
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {suggestions.map((suggestion, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border transition-colors cursor-pointer
                      ${selectedSuggestions[index]
                        ? 'bg-blue-500/10 border-blue-500/50'
                        : 'bg-white/5 border-white/10 hover:bg-white/10'
                      }`}
                    onClick={() => setSelectedSuggestions(prev => ({
                      ...prev,
                      [index]: !prev[index]
                    }))}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-sm font-medium px-2 py-1 rounded
                        ${suggestion.type === 'habit'
                          ? 'bg-purple-500/20 text-purple-400'
                          : 'bg-green-500/20 text-green-400'
                        }`}
                      >
                        {suggestion.type === 'habit' ? 'New Habit' : 'New Task'}
                      </span>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center
                        ${selectedSuggestions[index]
                          ? 'border-blue-500 bg-blue-500/20'
                          : 'border-gray-500'
                        }`}
                      >
                        {selectedSuggestions[index] && (
                          <CheckCircle className="w-4 h-4 text-blue-500" />
                        )}
                      </div>
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">
                      {suggestion.title}
                    </h3>
                    <p className="text-gray-400 text-sm mb-4">
                      {suggestion.description}
                    </p>
                    <div className="bg-white/5 rounded p-3">
                      <p className="text-sm text-blue-300">
                        <strong>Why this helps:</strong> {suggestion.reason}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-white/10 bg-black/20 sticky bottom-0 z-10">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-400">
              Select the suggestions you want to add
            </p>
            <button
              onClick={handleCreate}
              disabled={!Object.values(selectedSuggestions).some(Boolean) || creating}
              className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg
                hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {creating ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Plus className="w-5 h-5" />
              )}
              Create Selected
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}