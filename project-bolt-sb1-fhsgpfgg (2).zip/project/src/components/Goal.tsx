import React, { useState, useEffect, useCallback, memo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useHabitStore } from '../store/habitStore';
import { useTodoStore } from '../store/todoStore';
import { useAIRecommendations } from '../lib/recommendations';
import { useBookRecommendations } from '../lib/books';
import { ArrowLeft, Calendar, Award, Zap, BookOpen, Lightbulb, Target, AlertTriangle, ChevronDown, ChevronUp, Loader2, Plus, Rocket, Crosshair, Sparkles, Trash2, ArrowRight } from 'lucide-react';
import { format, addDays } from 'date-fns';
import { AIChat } from './AIChat';
import { supabase } from '../lib/supabase';
import { callOpenAI } from '../lib/openai';
import { BoostModal } from './BoostModal';

interface Goal {
  id: string;
  title: string;
  description: string;
  deadline?: string;
  color: GoalColor;
}

interface AIRecommendation {
  title: string;
  description: string;
  type: 'action' | 'insight' | 'milestone';
}

interface AIResponse {
  recommendations: AIRecommendation[];
}

interface Recommendation {
  id: string;
  goal_id: string;
  title: string;
  description: string;
  type: 'action' | 'insight' | 'milestone';
  created_at: string;
  updated_at: string;
}

type GoalColor = keyof typeof GOAL_COLORS;

const GOAL_COLORS = {
  blue: 'from-blue-500/20 to-blue-500/10',
  purple: 'from-purple-500/20 to-purple-500/10',
  green: 'from-green-500/20 to-green-500/10',
  rose: 'from-rose-500/20 to-rose-500/10',
  amber: 'from-amber-500/20 to-amber-500/10',
  cyan: 'from-cyan-500/20 to-cyan-500/10'
} as const;

interface RecommendationCardProps {
  recommendation: Recommendation;
  isExpanded: boolean;
  onToggle: () => void;
}

const RecommendationCard = memo(({ recommendation, isExpanded, onToggle }: RecommendationCardProps) => {
  const getIconForType = (type: string) => {
    switch (type) {
      case 'action':
        return <Rocket className="w-5 h-5" />;
      case 'insight':
        return <Lightbulb className="w-5 h-5" />;
      case 'milestone':
        return <Target className="w-5 h-5" />;
      default:
        return null;
    }
  };

  const getColorForType = (type: string) => {
    switch (type) {
      case 'action':
        return 'bg-blue-500/20 text-blue-400 hover:bg-blue-500/30';
      case 'insight':
        return 'bg-purple-500/20 text-purple-400 hover:bg-purple-500/30';
      case 'milestone':
        return 'bg-green-500/20 text-green-400 hover:bg-green-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 hover:bg-gray-500/30';
    }
  };

  return (
    <div 
      className={`flex flex-col w-full transition-all duration-300 ease-in-out cursor-pointer
        ${isExpanded ? 'bg-white/10' : 'bg-white/5'} 
        rounded-lg hover:bg-white/15`}
      onClick={onToggle}
    >
      <div className="p-4 flex items-center justify-between">
        <div className={`p-3 rounded-full ${getColorForType(recommendation.type)} transition-transform duration-300
          ${isExpanded ? 'scale-110' : 'scale-100'}`}>
          {getIconForType(recommendation.type)}
        </div>
        <div className="ml-2 flex-grow">
          <h3 className="font-medium text-gray-100 line-clamp-1">{recommendation.title}</h3>
        </div>
        <div className={`transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}>
          <ChevronDown className="w-5 h-5 text-gray-400" />
        </div>
      </div>
      
      <div className={`overflow-hidden transition-all duration-300 ease-in-out
        ${isExpanded ? 'max-h-48 opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className="px-4 pb-4 text-gray-300">
          {recommendation.description}
        </div>
      </div>
    </div>
  );
});

RecommendationCard.displayName = 'RecommendationCard';

export function Goal() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [goal, setGoal] = useState<Goal | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [generatingSuggestions, setGeneratingSuggestions] = useState(false);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [expandedRecommendations, setExpandedRecommendations] = useState<Record<string, boolean>>({});
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { createHabit } = useHabitStore();
  const { createTodo } = useTodoStore();
  const [loadingRecommendations, setLoadingRecommendations] = useState(true);
  const [selectedColor, setSelectedColor] = useState<GoalColor>('blue');
  const [showBoostModal, setShowBoostModal] = useState(false);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    deadline: format(addDays(new Date(), 30), 'yyyy-MM-dd')
  });
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    if (id) {
      fetchGoalAndRecommendations();
    } else {
      fetchGoals();
    }
  }, [id]);

  const toggleRecommendation = (recommendationId: string) => {
    setExpandedRecommendations(prev => ({
      ...prev,
      [recommendationId]: !prev[recommendationId]
    }));
  };

  const fetchGoalAndRecommendations = async () => {
    try {
      setLoadingRecommendations(true);

      const { data: goalData, error: goalError } = await supabase
        .from('goals')
        .select('*')
        .eq('id', id)
        .single();

      if (goalError) throw goalError;
      setGoal(goalData);

      const { data: recsData, error: recsError } = await supabase
        .from('goal_recommendations')
        .select('*')
        .eq('goal_id', id)
        .order('type', { ascending: true });

      if (recsError) throw recsError;

      if (recsData && recsData.length > 0) {
        setRecommendations(recsData);
        setShowRecommendations(true);
        setLoadingRecommendations(false);
        return;
      }

      await generateRecommendations(goalData);
    } catch (err) {
      console.error('Error fetching goal and recommendations:', err);
      setError(err instanceof Error ? err.message : 'Error fetching data');
      setLoadingRecommendations(false);
    }
  };

  const fetchGoals = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('goals')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setGoals(data || []);
    } catch (err) {
      console.error('Error fetching goals:', err);
      setError(err instanceof Error ? err.message : 'Error fetching goals');
    }
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!goal?.id) {
      setError('No goal ID found');
      return;
    }

    try {
      const { error: deleteError } = await supabase
        .from('goals')
        .delete()
        .eq('id', goal.id);

      if (deleteError) throw deleteError;
      
      navigate('/goals');
    } catch (err) {
      console.error('Error deleting goal:', err);
      setError(err instanceof Error ? err.message : 'Error deleting goal');
    }
  };

  const handleCreateGoal = () => {
    setShowCreateForm(true);
  };

  const handleSubmitGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    setError(null);

    try {
      if (!newGoal.title.trim() || !newGoal.description.trim()) {
        throw new Error('Please fill in all required fields');
      }

      const { data, error: createError } = await supabase
        .from('goals')
        .insert({
          title: newGoal.title,
          description: newGoal.description,
          deadline: new Date(newGoal.deadline).toISOString(),
          color: selectedColor
        })
        .select()
        .single();

      if (createError) throw createError;
      navigate(`/goals/${data.id}`);
    } catch (err) {
      console.error('Error creating goal:', err);
      setError(err instanceof Error ? err.message : 'Error creating goal');
    } finally {
      setCreating(false);
    }
  };

  const generateRecommendations = async (targetGoal: Goal | null = null) => {
    const currentGoal = targetGoal || goal;
    if (!currentGoal) return;

    try {
      setGeneratingSuggestions(true);
      setError(null);

      const prompt = `Analiza el siguiente objetivo y genera recomendaciones estratégicas:

Título: "${currentGoal.title}"
Descripción: ${currentGoal.description}
Fecha límite: ${currentGoal.deadline ? format(new Date(currentGoal.deadline), 'PPP') : 'No definida'}

Genera EXACTAMENTE UNA recomendación de cada tipo (3 en total):

1. ACCIÓN INMEDIATA (type: "action"):
   - Un paso concreto y accionable
   - Enfoque en el corto plazo
   - Resultado medible

2. INSIGHT ESTRATÉGICO (type: "insight"):
   - Un análisis profundo del objetivo
   - Una consideración importante
   - Un factor clave de éxito

3. HITO CLAVE (type: "milestone"):
   - Un punto de control importante
   - Un indicador de progreso
   - Una fecha sugerida

IMPORTANTE: Genera EXACTAMENTE 3 recomendaciones, UNA de cada tipo.

Responde en formato JSON con esta estructura exacta:
{
  "recommendations": [
    {
      "title": "título corto y específico",
      "description": "descripción detallada",
      "type": "action"
    },
    {
      "title": "título corto y específico",
      "description": "descripción detallada",
      "type": "insight"
    },
    {
      "title": "título corto y específico",
      "description": "descripción detallada",
      "type": "milestone"
    }
  ]
}`;

      const response = await callOpenAI(
        prompt,
        'Eres un experto en planificación estratégica y desarrollo personal. Tu objetivo es ayudar a las personas a alcanzar sus metas mediante un análisis profundo y recomendaciones accionables.'
      );

      const data = JSON.parse(response) as AIResponse;
      
      const { error: deleteError } = await supabase
        .from('goal_recommendations')
        .delete()
        .eq('goal_id', currentGoal.id);

      if (deleteError) throw deleteError;

      const { error: insertError } = await supabase
        .from('goal_recommendations')
        .insert(
          data.recommendations.map(rec => ({
            goal_id: currentGoal.id,
            title: rec.title,
            description: rec.description,
            type: rec.type,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }))
        );

      if (insertError) throw insertError;

      const { data: recommendations, error: fetchError } = await supabase
        .from('goal_recommendations')
        .select('*')
        .eq('goal_id', currentGoal.id)
        .order('type', { ascending: true });

      if (fetchError) throw fetchError;

      setRecommendations(recommendations);
      setShowRecommendations(true);
    } catch (err) {
      console.error('Error generating recommendations:', err);
      setError(err instanceof Error ? err.message : 'Error generating recommendations');
    } finally {
      setGeneratingSuggestions(false);
      setLoadingRecommendations(false);
    }
  };

  if (!id) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-blue-950 text-white p-4 sm:p-8 pb-32">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            {showCreateForm ? (
              <div className="max-w-lg mx-auto">
                <h2 className="text-2xl font-bold mb-6">Create New Goal</h2>
                <form onSubmit={handleSubmitGoal} className="space-y-6">
                  <div>
                    <label htmlFor="title" className="block text-sm font-medium text-blue-200 mb-1">
                      Goal Title
                    </label>
                    <input
                      type="text"
                      id="title"
                      value={newGoal.title}
                      onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg 
                        text-gray-100 placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                        transition-all duration-200"
                      placeholder="What do you want to achieve?"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="description" className="block text-sm font-medium text-blue-200 mb-1">
                      Description
                    </label>
                    <textarea
                      id="description"
                      value={newGoal.description}
                      onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg 
                        text-gray-100 placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                        transition-all duration-200 min-h-[100px] resize-y"
                      placeholder="Describe your goal in detail..."
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="deadline" className="block text-sm font-medium text-blue-200 mb-1">
                      Target Date
                    </label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-2.5 h-5 w-5 text-blue-200" />
                      <input
                        type="date"
                        id="deadline"
                        value={newGoal.deadline}
                        onChange={(e) => setNewGoal({ ...newGoal, deadline: e.target.value })}
                        className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg 
                          text-gray-100 focus:outline-none focus:border-blue-500/40
                          transition-all duration-200"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-blue-200 mb-2">
                      Goal Color
                    </label>
                    <div className="flex gap-3 justify-center">
                      {(Object.keys(GOAL_COLORS) as GoalColor[]).map((color) => (
                        <button
                          key={color}
                          type="button"
                          onClick={() => setSelectedColor(color)}
                          className={`w-8 h-8 rounded-full bg-gradient-to-br ${GOAL_COLORS[color]} 
                            transition-all duration-200 transform
                            ${selectedColor === color 
                              ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-gray-900' 
                              : 'hover:scale-105'}`}
                        />
                      ))}
                    </div>
                  </div>

                  {error && (
                    <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                      <p className="text-red-400 text-sm">{error}</p>
                    </div>
                  )}

                  <div className="flex gap-4 justify-end">
                    <button
                      type="button"
                      onClick={() => setShowCreateForm(false)}
                      className="px-4 py-2 text-blue-200 hover:text-white transition-colors duration-200"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={creating}
                      className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600
                        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                        focus:ring-offset-gray-900 disabled:opacity-50 disabled:cursor-not-allowed
                        transition-all duration-200 flex items-center gap-2"
                    >
                      {creating ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        <>
                          Create Goal
                          <ArrowRight className="w-5 h-5" />
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              <>
                {goals.length === 0 ? (
                  <>
                    <div className="mb-12">
                      <div className="reactor-container">
                        <div className="reactor-core-outer" />
                        <div className="reactor-core-inner" />
                        <div className="reactor-core" />
                      </div>
                    </div>

                    <h1 className="text-3xl font-bold mb-6">Transform Your Goals into Reality</h1>
                    
                    <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                      <div className="flex flex-col items-center">
                        <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center mb-4">
                          <Target className="w-6 h-6 text-blue-400" />
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Set Clear Goals</h3>
                        <p className="text-blue-200 text-sm">
                          Define your objectives with clarity and purpose. Break down big dreams into achievable milestones.
                        </p>
                      </div>

                      <div className="flex flex-col items-center">
                        <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center mb-4">
                          <Rocket className="w-6 h-6 text-purple-400" />
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Build Habits</h3>
                        <p className="text-blue-200 text-sm">
                          Get AI-powered suggestions for habits that align with your goals. Small, consistent actions lead to big results.
                        </p>
                      </div>

                      <div className="flex flex-col items-center">
                        <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
                          <Crosshair className="w-6 h-6 text-green-400" />
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Track Progress</h3>
                        <p className="text-blue-200 text-sm">
                          Monitor your journey with smart tracking tools. Celebrate wins and adjust your strategy as needed.
                        </p>
                      </div>
                    </div>
                  </>
                ) : (
                  <h1 className="text-3xl font-bold mb-8">Your Goals</h1>
                )}

                {goals.length > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                    {goals.map((goal) => (
                      <div
                        key={goal.id}
                        onClick={() => navigate(`/goals/${goal.id}`)}
                        className={`goal-card bg-gradient-to-br ${GOAL_COLORS[goal.color]} 
                          backdrop-blur-lg rounded-lg p-6 border border-white/10
                          hover:border-white/20 transition-all duration-500 cursor-pointer
                          transform hover:scale-[1.02]`}
                        style={{ '--goal-color': goal.color }}
                      >
                        <h3 className="text-lg font-semibold mb-2">{goal.title}</h3>
                        <p className="text-blue-200 text-sm line-clamp-2">{goal.description}</p>
                        {goal.deadline && (
                          <p className="text-xs text-blue-300 mt-4">
                            Due: {format(new Date(goal.deadline), 'PPP')}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                <button
                  onClick={handleCreateGoal}
                  className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600
                    focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                    focus:ring-offset-gray-900 transition-all duration-200 flex items-center gap-2 mx-auto"
                >
                  <Plus className="w-5 h-5" />
                  {goals.length > 0 ? 'Create New Goal' : 'Create Your First Goal'}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (!goal) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-blue-950 text-white p-4 sm:p-8 pb-32">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <p className="text-blue-200">Loading goal...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-blue-950 text-white p-4 sm:p-8">
      <div className="max-w-7xl mx-auto pb-32">
        <div className="relative">
          {/* Mobile header */}
          <div className="lg:hidden flex items-center justify-between mb-6">
            <button
              onClick={() => navigate('/goals')}
              className="text-gray-400 hover:text-white transition-colors duration-200"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <button
              onClick={handleDelete}
              className="text-gray-400 hover:text-red-400 transition-colors duration-200"
            >
              <Trash2 className="w-6 h-6" />
            </button>
          </div>

          {/* Desktop header */}
          <div className="hidden lg:flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold">{goal.title}</h1>
            <div className="flex items-center gap-4">
              <button
                onClick={handleDelete}
                className="text-gray-400 hover:text-red-400 transition-colors duration-200"
              >
                <Trash2 className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Mobile title */}
          <h1 className="lg:hidden text-2xl font-bold mb-4">{goal.title}</h1>

          <p className="text-blue-200 mb-8">{goal.description}</p>

          <div className="space-y-8">
            {/* Chat section */}
            <div className="w-full max-w-3xl mx-auto">
              <AIChat goal={goal} />
            </div>

            {/* Recommendations section */}
            <div className="mt-12 mb-8">
              <h2 className="text-2xl font-bold text-gray-100 mb-6 text-center">Core Tips</h2>
              
              {loadingRecommendations ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <Loader2 className="w-12 h-12 text-blue-400 animate-spin mb-4" />
                  <p className="text-blue-200">Generating AI recommendations...</p>
                </div>
              ) : recommendations.length > 0 ? (
                <div className="flex flex-col md:flex-row gap-6 animate-fade-in">
                  {recommendations.map((rec) => (
                    <div key={rec.id} className="flex-1">
                      <RecommendationCard 
                        recommendation={rec}
                        isExpanded={!!expandedRecommendations[rec.id]}
                        onToggle={() => toggleRecommendation(rec.id)}
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <button
                    onClick={() => generateRecommendations()}
                    disabled={generatingSuggestions}
                    className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600
                      focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                      focus:ring-offset-gray-900 disabled:opacity-50 disabled:cursor-not-allowed
                      transition-all duration-200 flex items-center gap-2 mx-auto"
                  >
                    {generatingSuggestions ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Generating recommendations...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Get AI Recommendations
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Boost section */}
            <div className="flex flex-col items-center justify-center py-12 border-t border-white/10">
              <h2 className="text-2xl font-bold text-gray-100 mb-4">Need a Boost?</h2>
              <p className="text-gray-400 mb-8 text-center max-w-lg">
                Let AI suggest new habits and tasks that will help you achieve your goal faster
              </p>
              <button
                onClick={() => setShowBoostModal(true)}
                className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl
                  hover:from-blue-700 hover:to-purple-700 transform hover:scale-105
                  transition-all duration-200 shadow-lg hover:shadow-xl
                  flex items-center gap-3 font-medium"
              >
                <Sparkles className="w-6 h-6" />
                Get AI Boost
              </button>
            </div>

            {showBoostModal && (
              <BoostModal
                goal={goal}
                onClose={() => setShowBoostModal(false)}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}