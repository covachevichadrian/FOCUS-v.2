import React, { useState, useRef, useEffect, useCallback, memo } from 'react';
import { Plus, Trash2, GripVertical, Camera, Clock, Calendar } from 'lucide-react';
import { useNoteStore, type Note } from '../store/noteStore';
import { format } from 'date-fns';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragStartEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { ImageCapture } from './ImageCapture';

interface SortableNoteItemProps {
  note: Note;
  onDelete: (id: string) => void;
  onEdit: (id: string, title: string, content?: string, reminderAt?: Date | null) => void;
  isDragging?: boolean;
}

const SortableNoteItem = memo(({ 
  note, 
  onDelete,
  onEdit,
  isDragging,
}: SortableNoteItemProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(note.title);
  const [editContent, setEditContent] = useState(note.content || '');
  const [reminderDate, setReminderDate] = useState(
    note.reminder_at ? format(new Date(note.reminder_at), 'yyyy-MM-dd') : ''
  );
  const [reminderTime, setReminderTime] = useState(
    note.reminder_at ? format(new Date(note.reminder_at), 'HH:mm') : ''
  );
  
  const editRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (isEditing && editRef.current && !editRef.current.contains(event.target as Node)) {
        handleSave();
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isEditing, editTitle, editContent, reminderDate, reminderTime]);

  useEffect(() => {
    if (!isEditing) {
      setEditTitle(note.title);
      setEditContent(note.content || '');
      setReminderDate(note.reminder_at ? format(new Date(note.reminder_at), 'yyyy-MM-dd') : '');
      setReminderTime(note.reminder_at ? format(new Date(note.reminder_at), 'HH:mm') : '');
    }
  }, [note, isEditing]);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: note.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition: isDragging ? 'none' : transition,
  };

  const handleSave = async () => {
    if (!editTitle.trim()) {
      setIsEditing(false);
      setEditTitle(note.title);
      setEditContent(note.content || '');
      setReminderDate(note.reminder_at ? format(new Date(note.reminder_at), 'yyyy-MM-dd') : '');
      setReminderTime(note.reminder_at ? format(new Date(note.reminder_at), 'HH:mm') : '');
      return;
    }

    let reminderAt: Date | null | undefined;
    if (reminderDate && reminderTime) {
      reminderAt = new Date(`${reminderDate}T${reminderTime}`);
    } else if (!reminderDate && !reminderTime) {
      reminderAt = null;
    }
    
    await onEdit(
      note.id, 
      editTitle.trim(), 
      editContent.trim() || undefined,
      reminderAt
    );
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSave();
    } else if (e.key === 'Escape') {
      setIsEditing(false);
      setEditTitle(note.title);
      setEditContent(note.content || '');
      setReminderDate(note.reminder_at ? format(new Date(note.reminder_at), 'yyyy-MM-dd') : '');
      setReminderTime(note.reminder_at ? format(new Date(note.reminder_at), 'HH:mm') : '');
    }
  };

  return (
    <li
      ref={setNodeRef}
      style={style}
      className={`flex items-start gap-3 p-4 bg-white/5 backdrop-blur-lg rounded-lg border border-white/10 
        hover:border-white/20 transition-all duration-200 group
        ${isDragging ? 'border-white/20 shadow-lg' : ''}`}
    >
      <button
        {...attributes}
        {...listeners}
        className="touch-none text-white/40 hover:text-white/60 transition-colors duration-200 cursor-grab active:cursor-grabbing mt-1"
      >
        <GripVertical className="w-5 h-5" />
      </button>

      <div 
        ref={editRef}
        className="flex-1 min-w-0 cursor-pointer"
        onClick={() => !isEditing && setIsEditing(true)}
      >
        {isEditing ? (
          <div className="space-y-4">
            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg 
                text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                transition-all duration-200"
              placeholder="Note title"
              autoFocus
            />
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg 
                text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                transition-all duration-200 min-h-[120px] resize-y"
              placeholder="Write your note here..."
            />
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-blue-200 mb-1">
                  Reminder Date
                </label>
                <input
                  type="date"
                  value={reminderDate}
                  onChange={(e) => setReminderDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg 
                    text-white focus:outline-none focus:border-blue-500/40
                    transition-all duration-200"
                />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium text-blue-200 mb-1">
                  Reminder Time
                </label>
                <input
                  type="time"
                  value={reminderTime}
                  onChange={(e) => setReminderTime(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg 
                    text-white focus:outline-none focus:border-blue-500/40
                    transition-all duration-200"
                />
              </div>
            </div>
          </div>
        ) : (
          <>
            <h3 className="text-white group-hover:text-blue-200 transition-colors duration-200">
              {note.title}
            </h3>
            {note.content && (
              <p className="mt-2 text-sm text-blue-200/60 group-hover:text-blue-200/80 transition-colors duration-200 whitespace-pre-wrap">
                {note.content}
              </p>
            )}
            <div className="mt-2 flex items-center gap-4 text-xs text-blue-200/60">
              <p className="group-hover:text-blue-200/80 transition-colors duration-200">
                Last updated: {format(new Date(note.updated_at), 'MMM d, yyyy h:mm a')}
              </p>
              {note.reminder_at && (
                <div className="flex items-center gap-1 text-blue-200/60">
                  <Clock className="w-4 h-4" />
                  <span>Due {format(new Date(note.reminder_at), 'MMM d, h:mm a')}</span>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      <button
        onClick={() => onDelete(note.id)}
        className="text-white/40 hover:text-white/60 transition-colors duration-200 mt-1 opacity-0 group-hover:opacity-100"
      >
        <Trash2 className="w-5 h-5" />
      </button>
    </li>
  );
});

SortableNoteItem.displayName = 'SortableNoteItem';

export function NoteList() {
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [reminderDate, setReminderDate] = useState('');
  const [reminderTime, setReminderTime] = useState('');
  
  const { 
    notes, 
    createNote, 
    deleteNote, 
    updateNote,
    reorderNotes
  } = useNoteStore();

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleCreateNote = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    
    try {
      let reminderAt: Date | undefined;
      if (reminderDate && reminderTime) {
        reminderAt = new Date(`${reminderDate}T${reminderTime}`);
      }
      
      await createNote(newTitle, newContent, reminderAt);
      setNewTitle('');
      setNewContent('');
      setReminderDate('');
      setReminderTime('');
      setIsExpanded(false);
    } catch (error) {
      console.error('Failed to create note:', error);
    }
  }, [newTitle, newContent, reminderDate, reminderTime, createNote]);

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  }, []);

  const handleDragEnd = useCallback(async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);
    
    if (over && active.id !== over.id) {
      const oldIndex = notes.findIndex(n => n.id === active.id);
      const newIndex = notes.findIndex(n => n.id === over.id);
      
      const reorderedNotes = arrayMove(notes, oldIndex, newIndex).map((note, index) => ({
        ...note,
        position: index
      }));
      
      await reorderNotes(reorderedNotes);
    }
  }, [notes, reorderNotes]);

  const handleImageCapture = useCallback((text: string) => {
    if (text) {
      setNewContent(prev => {
        const prefix = prev ? prev + '\n\n' : '';
        return prefix + text;
      });
      setIsExpanded(true);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-blue-950 text-white p-4 sm:p-8">
      <div className="max-w-4xl mx-auto pb-24">
        <form onSubmit={handleCreateNote} className="mb-8">
          <div className="relative flex items-center gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                onFocus={() => setIsExpanded(true)}
                placeholder="Add a new note..."
                className="w-full pl-4 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg 
                  text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                  transition-all duration-200"
              />
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                type="button"
                onClick={() => setShowCamera(true)}
                className="p-3 bg-white/5 text-white rounded-lg hover:bg-white/10 
                  focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                  focus:ring-offset-gray-900 transition-all duration-200"
              >
                <Camera className="w-5 h-5" />
              </button>
              <button
                type="submit"
                className="p-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 
                  focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                  focus:ring-offset-gray-900 transition-all duration-200"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className={`overflow-hidden transition-[max-height,opacity] duration-300 ease-in-out ${
            isExpanded ? 'max-h-[400px] opacity-100 mt-4' : 'max-h-0 opacity-0'
          }`}>
            <div className="space-y-4 transform transition-transform duration-300 ease-in-out">
              <textarea
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="Write your note here..."
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg 
                  text-white placeholder-blue-200/60 focus:outline-none focus:border-blue-500/40
                  transition-all duration-200 min-h-[120px] resize-y"
              />
              
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    Reminder Date
                  </label>
                  <input
                    type="date"
                    value={reminderDate}
                    onChange={(e) => setReminderDate(e.target.value)}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg 
                      text-white focus:outline-none focus:border-blue-500/40
                      transition-all duration-200"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-blue-200 mb-2">
                    Reminder Time
                  </label>
                  <input
                    type="time"
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value)}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg 
                      text-white focus:outline-none focus:border-blue-500/40
                      transition-all duration-200"
                  />
                </div>
              </div>
            </div>
          </div>
        </form>

        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={notes}
            strategy={verticalListSortingStrategy}
          >
            <ul className="space-y-3">
              {notes.map(note => (
                <SortableNoteItem
                  key={note.id}
                  note={note}
                  onDelete={deleteNote}
                  onEdit={updateNote}
                  isDragging={note.id === activeId}
                />
              ))}
            </ul>
          </SortableContext>
        </DndContext>

        {showCamera && (
          <ImageCapture
            onCapture={handleImageCapture}
            onClose={() => setShowCamera(false)}
          />
        )}
      </div>
    </div>
  );
}