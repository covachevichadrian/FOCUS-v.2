import React, { useState, useRef } from 'react';
import { Upload, X, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface LogoUploadProps {
  onUpload: (url: string) => void;
  currentLogo?: string;
}

export function LogoUpload({ onUpload, currentLogo }: LogoUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file');
      return;
    }

    // Check file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setError('Image size should be less than 2MB');
      return;
    }

    try {
      setIsUploading(true);
      setError(null);

      // Generate a unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${fileName}`;

      // Upload to Supabase Storage
      const { error: uploadError, data } = await supabase.storage
        .from('logos')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('logos')
        .getPublicUrl(filePath);

      onUpload(publicUrl);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to upload logo';
      setError(`Upload error: ${errorMessage}`);
      console.error('Error uploading logo:', err);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      {currentLogo && (
        <div className="relative">
          <img
            src={currentLogo}
            alt="Current logo"
            className="w-24 h-24 object-contain rounded-lg"
          />
          <button
            onClick={() => onUpload('')}
            className="absolute -top-2 -right-2 p-1 bg-red-100 text-red-600 rounded-full 
              hover:bg-red-200 transition-colors duration-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-600">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}

      <button
        onClick={() => fileInputRef.current?.click()}
        disabled={isUploading}
        className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md
          text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2
          focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
      >
        <Upload className="w-5 h-5 mr-2" />
        {isUploading ? 'Uploading...' : currentLogo ? 'Change Logo' : 'Upload Logo'}
      </button>
    </div>
  );
}