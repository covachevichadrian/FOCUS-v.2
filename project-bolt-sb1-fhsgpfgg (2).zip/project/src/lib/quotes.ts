import { useState } from 'react';

export interface Quote {
  q: string;
  a: string;
}

// Curated list of high-quality fallback quotes
const FALLBACK_QUOTES = [
  { q: "El futuro depende de lo que hagas hoy.", a: "Mahatma Gandhi" },
  { q: "El éxito no es definitivo, el fracaso no es fatal: lo que cuenta es el valor para continuar.", a: "Winston Churchill" },
  { q: "La única forma de hacer un gran trabajo es amar lo que haces.", a: "Steve Jobs" },
  { q: "No mires el reloj; haz lo que él hace. Sigue adelante.", a: "Sam Levenson" },
  { q: "La manera de empezar es dejar de hablar y empezar a hacer.", a: "Walt Disney" },
  { q: "No importa lo lento que vayas, siempre y cuando no te detengas.", a: "Confucio" },
  { q: "Todo lo que siempre has querido está al otro lado del miedo.", a: "George Addair" },
  { q: "El éxito es ir de fracaso en fracaso sin perder el entusiasmo.", a: "Winston Churchill" },
  { q: "Cree que puedes y estás a medio camino.", a: "Theodore Roosevelt" },
  { q: "Todo lo que puedes imaginar es real.", a: "Pablo Picasso" }
];

function getRandomFallbackQuote(): Quote {
  const today = new Date();
  const dayOfYear = Math.floor(
    (today - new Date(today.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24)
  );
  return FALLBACK_QUOTES[dayOfYear % FALLBACK_QUOTES.length];
}

export function useQuote() {
  const [quote] = useState<Quote>(getRandomFallbackQuote());
  return { quote, error: false };
}