import { useEffect, useState } from 'react';
import { supabase } from './supabase';
import { callOpenAI, validateOpenAIResponse, getHabitPrompt } from './openai';

export interface Recommendation {
  id: string;
  habit_id: string;
  title: string;
  description: string;
  type: 'tip' | 'milestone' | 'challenge' | 'warning';
  level: 'beginner' | 'intermediate' | 'advanced';
  progress_snapshot: {
    streak: number;
    active_days: number[];
    total_completions: number;
    completion_rate: number;
  };
  created_at: string;
  updated_at: string;
}

interface AIRecommendation {
  title: string;
  description: string;
  type: 'tip' | 'milestone' | 'challenge' | 'warning';
}

interface AIResponse {
  recommendations: AIRecommendation[];
}

export function useAIRecommendations(habit: Habit | undefined) {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!habit) {
      setRecommendations([]);
      setError(null);
      return;
    }

    let mounted = true;
    setLoading(true);
    setError(null);

    async function fetchRecommendations() {
      try {
        // First try to get existing recommendations
        const { data: existingRecs, error: fetchError } = await supabase
          .from('habit_recommendations')
          .select()
          .eq('habit_id', habit.id)
          .order('type', { ascending: true });

        if (fetchError) throw fetchError;

        // Get total completions and completion rate
        const { data: completions } = await supabase
          .from('habit_completions')
          .select('completed_at')
          .eq('habit_id', habit.id);

        const totalCompletions = completions?.length || 0;
        const daysActive = (new Date().getTime() - new Date(habit.created_at).getTime()) / (1000 * 60 * 60 * 24);
        const expectedCompletions = Math.floor(daysActive * (habit.active_days.length / 7));
        const completionRate = expectedCompletions > 0 ? totalCompletions / expectedCompletions : 0;

        // Determine current level
        const level = habit.streak < 7 ? 'beginner' : 
                     habit.streak < 30 ? 'intermediate' : 
                     'advanced';

        // Create progress snapshot
        const progressSnapshot = {
          streak: habit.streak,
          active_days: habit.active_days,
          total_completions: totalCompletions,
          completion_rate: completionRate
        };

        // If we have recommendations, check if we need to update them
        if (existingRecs && existingRecs.length > 0) {
          const { data: shouldUpdate } = await supabase.rpc(
            'should_update_recommendations',
            { 
              p_habit_id: habit.id,
              p_last_update: existingRecs[0].updated_at
            }
          );

          // If we don't need to update, return existing recommendations
          if (!shouldUpdate) {
            if (mounted) {
              setRecommendations(existingRecs);
              setLoading(false);
            }
            return;
          }
        }

        // Generate new recommendations
        const prompt = getHabitPrompt(habit, level, progressSnapshot);
        const response = await callOpenAI(prompt, 'Eres un asistente experto en desarrollo de hábitos saludables.');
        const data = validateOpenAIResponse<AIResponse>(response);

        // Store new recommendations
        const { data: newRecs, error: insertError } = await supabase
          .from('habit_recommendations')
          .upsert(
            data.recommendations.map(rec => ({
              habit_id: habit.id,
              title: rec.title,
              description: rec.description,
              type: rec.type,
              level,
              progress_snapshot: progressSnapshot,
              updated_at: new Date().toISOString()
            })),
            { onConflict: 'habit_id,type' }
          )
          .select();

        if (insertError) throw insertError;

        if (mounted && newRecs) {
          setRecommendations(newRecs);
          setLoading(false);
        }
      } catch (err) {
        console.error('Error fetching recommendations:', err);
        if (mounted) {
          setError(err instanceof Error ? err.message : 'Error fetching recommendations');
          setLoading(false);
        }
      }
    }

    fetchRecommendations();

    return () => {
      mounted = false;
    };
  }, [habit]);

  return { recommendations, loading, error };
}