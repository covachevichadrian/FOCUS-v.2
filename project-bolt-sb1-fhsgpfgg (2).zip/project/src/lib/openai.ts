import { type Habit } from '../store/habitStore';

const DEEPSEEK_API_KEY = import.meta.env.VITE_DEEPSEEK_API_KEY;
const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions';

interface DeepSeekResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: {
    message: {
      role: string;
      content: string;
    };
    index: number;
    finish_reason: string;
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

interface DeepSeekError {
  error: {
    message: string;
    type: string;
    param: Record<string, unknown>;
    code: string;
  };
}

export async function callOpenAI(prompt: string, systemPrompt: string): Promise<string> {
  try {
    const response = await fetch(DEEPSEEK_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          {
            role: 'system',
            content: systemPrompt
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1000,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      const error = await response.json() as DeepSeekError;
      throw new Error(error.error.message);
    }

    const data = await response.json() as DeepSeekResponse;
    return data.choices[0].message.content;
  } catch (error) {
    console.error('Error calling DeepSeek API:', error);
    throw error;
  }
}

export function validateOpenAIResponse<T>(content: string): T {
  try {
    return JSON.parse(content) as T;
  } catch (error) {
    console.error('Error parsing DeepSeek response:', error);
    throw new Error('Invalid response format');
  }
}

export function getHabitPrompt(
  habit: Habit, 
  level: 'beginner' | 'intermediate' | 'advanced',
  progress: {
    streak: number;
    active_days: number[];
    total_completions: number;
    completion_rate: number;
  }
): string {
  return `Genera 4 recomendaciones personalizadas para alguien que está desarrollando el hábito de "${habit.name}".

Contexto del hábito:
- Nivel: ${level}
- Racha actual: ${progress.streak} días
- Días activos por semana: ${progress.active_days.length}
- Días activos: ${progress.active_days.map(d => ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'][d]).join(', ')}
- Total completados: ${progress.total_completions}
- Tasa de cumplimiento: ${Math.round(progress.completion_rate * 100)}%

REGLAS ESTRICTAS:
1. DEBES generar EXACTAMENTE 4 recomendaciones, una de cada tipo:

   TIP (consejo práctico):
   - Un consejo específico y accionable
   - Enfocado en la ejecución diaria
   - Debe ser fácil de implementar inmediatamente
   - Adaptado al nivel ${level}

   MILESTONE (hito):
   - Un objetivo específico a alcanzar
   - Relacionado con el progreso actual (racha: ${progress.streak})
   - Debe ser medible y alcanzable
   - Considera la tasa de cumplimiento actual

   CHALLENGE (desafío):
   - Una tarea desafiante pero realizable
   - Debe empujar los límites actuales
   - Adaptado al nivel ${level}
   - Considera los días activos actuales

   WARNING (advertencia):
   - Un obstáculo común a evitar
   - Basado en errores típicos del nivel ${level}
   - Debe incluir cómo prevenirlo
   - Considera la tasa de cumplimiento

2. Las recomendaciones DEBEN:
   - Ser específicas para el nivel ${level}
   - Considerar la frecuencia de ${progress.active_days.length} días/semana
   - NO ser genéricas ni repetitivas
   - Estar adaptadas específicamente a "${habit.name}"
   - Considerar el progreso actual y la tasa de cumplimiento

Responde SOLO con un objeto JSON con este formato exacto:
{
  "recommendations": [
    {
      "title": "título corto y específico",
      "description": "descripción detallada y accionable",
      "type": "tip"
    },
    {
      "title": "título corto y específico",
      "description": "descripción detallada y accionable",
      "type": "milestone"
    },
    {
      "title": "título corto y específico",
      "description": "descripción detallada y accionable",
      "type": "challenge"
    },
    {
      "title": "título corto y específico",
      "description": "descripción detallada y accionable",
      "type": "warning"
    }
  ]
}

IMPORTANTE: Las recomendaciones DEBEN seguir EXACTAMENTE este orden: tip, milestone, challenge, warning.`;
}

export function getBookPrompt(habitName: string): string {
  return `Recomienda EXACTAMENTE 3 libros específicos y reales para alguien que quiere desarrollar el hábito de "${habitName}".

Responde SOLO con un objeto JSON con este formato exacto:
{
  "books": [
    {
      "title": "título exacto del libro",
      "authors": ["autor 1", "autor 2"],
      "description": "descripción específica del libro y su relevancia para ${habitName}"
    }
  ]
}

IMPORTANTE:
- Los libros DEBEN ser reales y estar disponibles en español o inglés
- Las recomendaciones deben ser relevantes para el desarrollo de este hábito específico
- DEBES recomendar EXACTAMENTE 3 libros, ni más ni menos
- Los libros DEBEN tener enfoques complementarios, no redundantes`;
}