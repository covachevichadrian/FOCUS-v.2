import { supabase } from './supabase';

// Check if the browser supports notifications
const isNotificationSupported = 'Notification' in window;

// Request notification permission
export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNotificationSupported) {
    console.warn('Notifications are not supported in this browser');
    return false;
  }

  try {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    return false;
  }
}

// Register service worker for PWA support
export async function registerServiceWorker(): Promise<void> {
  // Skip service worker registration in StackBlitz or if service workers aren't supported
  if (window.location.hostname.includes('stackblitz') || !('serviceWorker' in navigator)) {
    return;
  }

  try {
    const registration = await navigator.serviceWorker.register('/sw.js');
    console.log('Service Worker registered:', registration);
  } catch (error) {
    console.error('Service Worker registration failed:', error);
  }
}

// Show a notification
export function showNotification(title: string, options?: NotificationOptions): void {
  if (!isNotificationSupported || Notification.permission !== 'granted') {
    return;
  }

  try {
    // Create a simple notification
    new Notification(title, {
      ...options,
      icon: '/pwa-64x64.png',
      badge: '/pwa-64x64.png',
      silent: false,
      requireInteraction: true
    });
  } catch (error) {
    console.error('Error showing notification:', error);
  }
}

// Check for due reminders
export async function checkReminders(): Promise<void> {
  try {
    // Check todos
    const { data: dueTodos, error: todosError } = await supabase
      .from('todos')
      .select('*')
      .eq('completed', false)
      .eq('reminder_sent', false)
      .lte('reminder_at', new Date().toISOString());

    if (todosError) throw todosError;

    if (dueTodos) {
      for (const todo of dueTodos) {
        showNotification('Recordatorio de tarea', {
          body: todo.title,
          tag: `todo-${todo.id}`,
          data: { type: 'todo', id: todo.id },
          requireInteraction: true
        });

        // Mark reminder as sent
        await supabase
          .from('todos')
          .update({ reminder_sent: true })
          .eq('id', todo.id);
      }
    }

    // Check notes
    const { data: dueNotes, error: notesError } = await supabase
      .from('notes')
      .select('*')
      .eq('reminder_sent', false)
      .lte('reminder_at', new Date().toISOString());

    if (notesError) throw notesError;

    if (dueNotes) {
      for (const note of dueNotes) {
        showNotification('Recordatorio de nota', {
          body: note.title,
          tag: `note-${note.id}`,
          data: { type: 'note', id: note.id },
          requireInteraction: true
        });

        // Mark reminder as sent
        await supabase
          .from('notes')
          .update({ reminder_sent: true })
          .eq('id', note.id);
      }
    }
  } catch (error) {
    console.error('Error checking reminders:', error);
  }
}

// Start reminder checker
let reminderInterval: NodeJS.Timeout;

export function startReminderChecker(): void {
  // Clear any existing interval
  if (reminderInterval) {
    clearInterval(reminderInterval);
  }

  // Check immediately
  checkReminders();

  // Then check every minute
  reminderInterval = setInterval(checkReminders, 60 * 1000);
}

export function stopReminderChecker(): void {
  if (reminderInterval) {
    clearInterval(reminderInterval);
  }
}