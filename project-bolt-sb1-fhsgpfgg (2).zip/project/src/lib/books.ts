import { useEffect, useState } from 'react';
import { supabase } from './supabase';
import { callOpenAI, validateOpenAIResponse, getBookPrompt } from './openai';

export interface Book {
  id: string;
  habit_id: string;
  title: string;
  authors: string[];
  description: string;
  image_url?: string;
  preview_link?: string;
  created_at: string;
  updated_at: string;
  last_viewed_at: string | null;
}

interface AIBook {
  title: string;
  authors: string[];
  description: string;
}

interface AIResponse {
  books: AIBook[];
}

export function useBookRecommendations(habitId: string | undefined) {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!habitId) {
      setBooks([]);
      setError(null);
      return;
    }

    let mounted = true;
    setLoading(true);
    setError(null);

    async function fetchBooks() {
      try {
        // First try to get existing books
        const { data: existingBooks, error: fetchError } = await supabase
          .from('habit_book_recommendations')
          .select()
          .eq('habit_id', habitId)
          .order('created_at', { ascending: true });

        if (fetchError) throw fetchError;

        // If we have books and they're recent, use them
        if (existingBooks && existingBooks.length > 0) {
          const lastUpdated = new Date(existingBooks[0].updated_at);
          const now = new Date();
          const daysSinceUpdate = (now.getTime() - lastUpdated.getTime()) / (1000 * 60 * 60 * 24);

          if (daysSinceUpdate < 7) {
            if (mounted) {
              setBooks(existingBooks);
              setLoading(false);
            }
            return;
          }
        }

        // Get habit name for the prompt
        const { data: habit } = await supabase
          .from('habits')
          .select('name')
          .eq('id', habitId)
          .single();

        if (!habit) throw new Error('Habit not found');

        // Generate new book recommendations
        const prompt = getBookPrompt(habit.name);
        const response = await callOpenAI(prompt, 'You are a helpful AI assistant that provides book recommendations.');
        const data = validateOpenAIResponse<AIResponse>(response);

        // Store new books
        const { data: newBooks, error: insertError } = await supabase
          .from('habit_book_recommendations')
          .upsert(
            data.books.map(book => ({
              habit_id: habitId,
              title: book.title,
              authors: book.authors,
              description: book.description,
              updated_at: new Date().toISOString()
            })),
            { onConflict: 'habit_id,title' }
          )
          .select();

        if (insertError) throw insertError;

        if (mounted && newBooks) {
          setBooks(newBooks);
          setLoading(false);
        }
      } catch (err) {
        console.error('Error fetching book recommendations:', err);
        if (mounted) {
          setError(err instanceof Error ? err.message : 'Error fetching book recommendations');
          setLoading(false);
        }
      }
    }

    fetchBooks();

    return () => {
      mounted = false;
    };
  }, [habitId]);

  return { books, loading, error };
}