import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { addDays, format, startOfToday } from 'date-fns';
import { es } from 'date-fns/locale';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getLastNDays(n: number): Date[] {
  const today = startOfToday();
  const dates: Date[] = [];
  
  for (let i = 0; i < n; i++) {
    dates.push(addDays(today, i));
  }
  
  return dates;
}

export function formatDate(date: Date): string {
  // Capitalizar primera letra del día
  const weekday = format(date, 'EEEE', { locale: es });
  const capitalizedWeekday = weekday.charAt(0).toUpperCase() + weekday.slice(1);
  
  // Obtener el número del día
  const dayNumber = format(date, 'd');
  
  return `${capitalizedWeekday} ${dayNumber}`;
}

export function calculateStreak(completedDates: Date[]): number {
  return completedDates.length;
}