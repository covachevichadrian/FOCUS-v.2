// Use native crypto instead of Node's crypto
const generateVAPIDKeys = () => {
  // Generate key pair
  const keyPair = crypto.subtle.generateKey(
    {
      name: 'ECDSA',
      namedCurve: 'P-256'
    },
    true,
    ['sign', 'verify']
  );

  // Export keys
  return keyPair.then(keys => {
    return Promise.all([
      crypto.subtle.exportKey('jwk', keys.publicKey),
      crypto.subtle.exportKey('jwk', keys.privateKey)
    ]);
  }).then(([publicKey, privateKey]) => {
    // Convert JWK to base64url
    const publicKeyBase64 = btoa(JSON.stringify(publicKey))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
    
    const privateKeyBase64 = btoa(JSON.stringify(privateKey))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    return {
      publicKey: publicKeyBase64,
      privateKey: privateKeyBase64
    };
  });
};

// Generate and log the keys
generateVAPIDKeys().then(vapidKeys => {
  console.log('VAPID Keys generated:');
  console.log('Public Key:', vapidKeys.publicKey);
  console.log('Private Key:', vapidKeys.privateKey);
  
  console.log('\nAdd these to your .env file:');
  console.log('VITE_VAPID_PUBLIC_KEY=' + vapidKeys.publicKey);
  console.log('VITE_VAPID_PRIVATE_KEY=' + vapidKeys.privateKey);
}).catch(error => {
  console.error('Error generating VAPID keys:', error);
});