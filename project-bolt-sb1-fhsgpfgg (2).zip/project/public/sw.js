// Service Worker version
const SW_VERSION = '1.0.0';

// Cache name
const CACHE_NAME = `focus-app-${SW_VERSION}`;

// Assets to cache
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Install event - cache assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  // Activate immediately
  self.skipWaiting();
});

// Activate event - clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name.startsWith('focus-app-') && name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    })
  );
  // Take control immediately
  self.clients.claim();
});

// Fetch event - serve from cache, then network
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});

// Background sync for notifications
self.addEventListener('sync', (event) => {
  if (event.tag === 'check-reminders') {
    event.waitUntil(checkReminders());
  }
});

// Periodic background sync for notifications
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'check-reminders') {
    event.waitUntil(checkReminders());
  }
});

// Push event - handle push notifications
self.addEventListener('push', (event) => {
  if (!event.data) return;

  const data = event.data.json();
  const options = {
    body: data.body,
    icon: '/pwa-64x64.png',
    badge: '/pwa-64x64.png',
    data: data.data,
    tag: data.tag,
    renotify: true,
    vibrate: [200, 100, 200],
    requireInteraction: true,
    actions: [
      {
        action: 'open',
        title: 'Abrir',
      },
      {
        action: 'close',
        title: 'Cerrar',
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Notification click event
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'close') {
    return;
  }

  const data = event.notification.data;
  if (!data) return;

  // Focus or open window and navigate to the appropriate route
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      if (clientList.length > 0) {
        const client = clientList[0];
        client.focus();
        if (data.type === 'todo') {
          client.navigate(`/todos#${data.id}`);
        } else if (data.type === 'note') {
          client.navigate(`/notes#${data.id}`);
        }
      } else {
        clients.openWindow(`/${data.type}s#${data.id}`);
      }
    })
  );
});

// Check reminders function
async function checkReminders() {
  try {
    const response = await fetch('/api/check-reminders', {
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to check reminders');
    }

    const reminders = await response.json();

    // Show notifications for each reminder
    await Promise.all(
      reminders.map(async (reminder) => {
        await self.registration.showNotification(reminder.title, {
          body: reminder.body,
          icon: '/pwa-64x64.png',
          badge: '/pwa-64x64.png',
          data: reminder.data,
          tag: reminder.tag,
          renotify: true,
          vibrate: [200, 100, 200],
          requireInteraction: true,
          actions: [
            {
              action: 'open',
              title: 'Abrir',
            },
            {
              action: 'close',
              title: 'Cerrar',
            }
          ]
        });
      })
    );
  } catch (error) {
    console.error('Error checking reminders:', error);
  }
}