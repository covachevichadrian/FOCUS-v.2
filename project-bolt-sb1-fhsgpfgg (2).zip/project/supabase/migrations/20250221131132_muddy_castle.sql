/*
  # Authentication Setup Migration

  1. Database Configuration
    - Enable UUID and pgcrypto extensions for cryptographic functions
    - Set appropriate timeouts for different roles
    - Configure row-level security for auth.users table

  Note: This migration sets up the basic authentication requirements
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Configure auth settings
ALTER ROLE authenticated SET statement_timeout = '8s';
ALTER ROLE service_role SET statement_timeout = '2h';

-- Enable email auth
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;