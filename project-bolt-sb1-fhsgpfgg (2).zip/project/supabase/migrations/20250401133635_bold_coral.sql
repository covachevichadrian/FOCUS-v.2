/*
  # Add goal recommendations table

  1. New Table
    - goal_recommendations
      - id (uuid, primary key)
      - goal_id (uuid, references goals)
      - title (text)
      - description (text)
      - type (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create goal recommendations table
CREATE TABLE IF NOT EXISTS goal_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  goal_id uuid REFERENCES goals ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  type text NOT NULL CHECK (type IN ('action', 'insight', 'milestone')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE goal_recommendations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can create recommendations for their goals"
  ON goal_recommendations FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view recommendations for their goals"
  ON goal_recommendations FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update recommendations for their goals"
  ON goal_recommendations FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete recommendations for their goals"
  ON goal_recommendations FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

-- Create index for goal_id
CREATE INDEX IF NOT EXISTS idx_goal_recommendations_goal_id ON goal_recommendations (goal_id);