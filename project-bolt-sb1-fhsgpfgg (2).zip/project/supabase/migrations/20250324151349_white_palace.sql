/*
  # Add INSERT policies for recommendations

  1. Changes
    - Add INSERT policies for habit_recommendations and habit_book_recommendations tables
    - Ensure users can only create recommendations for their own habits

  2. Security
    - Maintain existing RLS policies
    - Add proper checks for habit ownership
*/

-- Add INSERT policy for habit recommendations
CREATE POLICY "Users can create recommendations for their habits"
  ON habit_recommendations FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Add INSERT policy for book recommendations
CREATE POLICY "Users can create book recommendations for their habits"
  ON habit_book_recommendations FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );