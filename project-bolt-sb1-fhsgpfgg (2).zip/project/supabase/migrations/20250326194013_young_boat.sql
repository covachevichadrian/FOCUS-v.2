/*
  # Add reminders to notes

  1. Changes
    - Add reminder_at column to store when the reminder should trigger
    - Add reminder_sent column to track notification status
    - Add index on reminder_at for better query performance

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE notes 
ADD COLUMN IF NOT EXISTS reminder_at timestamptz,
ADD COLUMN IF NOT EXISTS reminder_sent boolean DEFAULT false;

CREATE INDEX IF NOT EXISTS idx_notes_reminder_at ON notes (reminder_at)
WHERE reminder_at IS NOT NULL;