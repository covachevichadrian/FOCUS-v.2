/*
  # Add reminders to todos

  1. Changes
    - Add reminder_at column to store when the reminder should trigger
    - Add reminder_sent column to track notification status
    - Add index on reminder_at for better query performance

  2. Security
    - Maintain existing RLS policies
    - No additional policies needed as the existing ones cover the new columns
*/

DO $$ 
BEGIN
  -- Add reminder columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'todos' 
    AND column_name = 'reminder_at'
  ) THEN
    ALTER TABLE todos ADD COLUMN reminder_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'todos' 
    AND column_name = 'reminder_sent'
  ) THEN
    ALTER TABLE todos ADD COLUMN reminder_sent boolean DEFAULT false;
  END IF;

  -- Create index for reminder_at if it doesn't exist
  IF NOT EXISTS (
    SELECT 1
    FROM pg_indexes
    WHERE tablename = 'todos'
    AND indexname = 'idx_todos_reminder_at'
  ) THEN
    CREATE INDEX idx_todos_reminder_at ON todos (reminder_at)
    WHERE reminder_at IS NOT NULL;
  END IF;
END $$;