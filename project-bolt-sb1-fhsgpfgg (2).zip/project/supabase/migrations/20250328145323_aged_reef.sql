/*
  # Restore recommendations tables

  1. New Tables
    - `habit_recommendations`
      - `id` (uuid, primary key)
      - `habit_id` (uuid, references habits)
      - `title` (text)
      - `description` (text)
      - `type` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `last_viewed_at` (timestamptz)

    - `habit_book_recommendations`
      - `id` (uuid, primary key)
      - `habit_id` (uuid, references habits)
      - `title` (text)
      - `authors` (text[])
      - `description` (text)
      - `image_url` (text)
      - `preview_link` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `last_viewed_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  -- Drop habit recommendations policies
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'habit_recommendations' AND policyname = 'Users can create recommendations for their habits'
  ) THEN
    DROP POLICY "Users can create recommendations for their habits" ON habit_recommendations;
  END IF;

  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'habit_recommendations' AND policyname = 'Users can view recommendations for their habits'
  ) THEN
    DROP POLICY "Users can view recommendations for their habits" ON habit_recommendations;
  END IF;

  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'habit_recommendations' AND policyname = 'Users can update recommendations for their habits'
  ) THEN
    DROP POLICY "Users can update recommendations for their habits" ON habit_recommendations;
  END IF;

  -- Drop habit book recommendations policies
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'habit_book_recommendations' AND policyname = 'Users can create book recommendations for their habits'
  ) THEN
    DROP POLICY "Users can create book recommendations for their habits" ON habit_book_recommendations;
  END IF;

  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'habit_book_recommendations' AND policyname = 'Users can view book recommendations for their habits'
  ) THEN
    DROP POLICY "Users can view book recommendations for their habits" ON habit_book_recommendations;
  END IF;

  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'habit_book_recommendations' AND policyname = 'Users can update book recommendations for their habits'
  ) THEN
    DROP POLICY "Users can update book recommendations for their habits" ON habit_book_recommendations;
  END IF;
END $$;

-- Create habit recommendations table
CREATE TABLE IF NOT EXISTS habit_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  type text NOT NULL CHECK (type IN ('tip', 'milestone', 'challenge', 'warning')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_viewed_at timestamptz
);

-- Create habit book recommendations table
CREATE TABLE IF NOT EXISTS habit_book_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  authors text[] NOT NULL,
  description text NOT NULL,
  image_url text,
  preview_link text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_viewed_at timestamptz
);

-- Enable RLS
ALTER TABLE habit_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE habit_book_recommendations ENABLE ROW LEVEL SECURITY;

-- Habit recommendations policies
CREATE POLICY "Users can create recommendations for their habits"
  ON habit_recommendations FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view recommendations for their habits"
  ON habit_recommendations FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update recommendations for their habits"
  ON habit_recommendations FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Book recommendations policies
CREATE POLICY "Users can create book recommendations for their habits"
  ON habit_book_recommendations FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view book recommendations for their habits"
  ON habit_book_recommendations FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update book recommendations for their habits"
  ON habit_book_recommendations FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );