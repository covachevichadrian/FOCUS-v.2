/*
  # Fresh Habits Schema with Proper Cleanup

  1. Changes
    - Drop all dependent tables first
    - Recreate tables with proper constraints
    - Set up RLS policies
    - Create trigger for streak calculation

  2. Notes
    - Uses CASCADE to properly handle dependencies
    - Maintains data integrity with constraints
*/

-- Drop existing tables and their dependencies
DROP TABLE IF EXISTS habit_book_recommendations CASCADE;
DROP TABLE IF EXISTS habit_recommendations CASCADE;
DROP TABLE IF EXISTS habit_completions CASCADE;
DROP TABLE IF EXISTS habits CASCADE;

-- Create habits table
CREATE TABLE habits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  streak integer DEFAULT 0,
  active_days integer[] DEFAULT ARRAY[0,1,2,3,4,5,6],
  CONSTRAINT valid_active_days CHECK (
    array_length(active_days, 1) > 0 
    AND array_length(active_days, 1) <= 7
    AND active_days <@ ARRAY[0,1,2,3,4,5,6]
  )
);

-- Create habit completions table
CREATE TABLE habit_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  completed_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT unique_habit_completion UNIQUE (habit_id, completed_at)
);

-- Enable RLS
ALTER TABLE habits ENABLE ROW LEVEL SECURITY;
ALTER TABLE habit_completions ENABLE ROW LEVEL SECURITY;

-- Habits policies
CREATE POLICY "Users can create their own habits"
  ON habits FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own habits"
  ON habits FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own habits"
  ON habits FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own habits"
  ON habits FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Habit completions policies
CREATE POLICY "Users can create completions for their habits"
  ON habit_completions FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view completions for their habits"
  ON habit_completions FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete completions for their habits"
  ON habit_completions FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Create function to update streak
CREATE OR REPLACE FUNCTION update_habit_streak()
RETURNS TRIGGER AS $$
DECLARE
  habit_record habits%ROWTYPE;
  current_streak integer := 0;
  last_completion_date date;
  current_date date;
  check_date date;
  completion_exists boolean;
  is_active_day boolean;
BEGIN
  -- Get habit information
  SELECT * INTO habit_record
  FROM habits
  WHERE id = COALESCE(NEW.habit_id, OLD.habit_id);

  IF habit_record IS NULL THEN
    RAISE EXCEPTION 'Habit not found';
  END IF;

  -- Get the most recent completion date
  SELECT MAX(completed_at::date)
  INTO current_date
  FROM habit_completions
  WHERE habit_id = habit_record.id;

  -- If we have a completion
  IF current_date IS NOT NULL THEN
    -- Initialize streak counter
    current_streak := 1;
    check_date := current_date - interval '1 day';

    -- Count backwards until we find a gap
    LOOP
      -- Check if this is an active day
      is_active_day := EXTRACT(DOW FROM check_date)::integer = ANY(habit_record.active_days);

      IF is_active_day THEN
        -- Check if the habit was completed on this date
        SELECT EXISTS (
          SELECT 1
          FROM habit_completions
          WHERE habit_id = habit_record.id
          AND completed_at::date = check_date
        ) INTO completion_exists;

        -- If we missed an active day, break the streak
        IF NOT completion_exists THEN
          EXIT;
        END IF;

        -- Increment streak for completed active days
        current_streak := current_streak + 1;
      END IF;

      -- Move to previous day
      check_date := check_date - interval '1 day';

      -- Stop if we've gone too far back (safety check)
      IF check_date < (current_date - interval '1 year') THEN
        EXIT;
      END IF;

      -- Check if there are any active days between the current date and check_date
      IF NOT EXISTS (
        SELECT 1
        FROM generate_series(check_date, current_date, interval '1 day') d
        WHERE EXTRACT(DOW FROM d)::integer = ANY(habit_record.active_days)
      ) THEN
        EXIT;
      END IF;
    END LOOP;
  END IF;

  -- Update the streak
  UPDATE habits 
  SET streak = current_streak
  WHERE id = habit_record.id;

  -- Return the appropriate record
  IF TG_OP = 'INSERT' THEN
    RETURN NEW;
  ELSE
    RETURN OLD;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for habit_completions
CREATE TRIGGER update_habit_streak_trigger
AFTER INSERT OR DELETE ON habit_completions
FOR EACH ROW
EXECUTE FUNCTION update_habit_streak();