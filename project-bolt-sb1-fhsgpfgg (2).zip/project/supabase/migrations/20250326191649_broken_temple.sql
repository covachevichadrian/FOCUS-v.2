/*
  # Initial Schema Setup

  1. Tables
    - habits
    - habit_completions
    - todos
    - notes

  2. Security
    - RLS policies for all tables
    - Authentication settings
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Configure auth settings
ALTER ROLE authenticated SET statement_timeout = '8s';
ALTER ROLE service_role SET statement_timeout = '2h';
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

-- Create habits table
CREATE TABLE IF NOT EXISTS habits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  streak integer DEFAULT 0,
  active_days integer[] DEFAULT ARRAY[0,1,2,3,4,5,6],
  CONSTRAINT valid_active_days CHECK (
    array_length(active_days, 1) > 0 
    AND array_length(active_days, 1) <= 7
    AND active_days <@ ARRAY[0,1,2,3,4,5,6]
  )
);

-- Create habit completions table
CREATE TABLE IF NOT EXISTS habit_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  completed_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create todos table
CREATE TABLE IF NOT EXISTS todos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL DEFAULT auth.uid(),
  title text NOT NULL,
  description text,
  completed boolean DEFAULT false,
  reminder_at timestamptz,
  reminder_sent boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  position integer DEFAULT 0
);

-- Create notes table
CREATE TABLE IF NOT EXISTS notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL DEFAULT auth.uid(),
  title text NOT NULL,
  content text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  position integer DEFAULT 0
);

-- Enable RLS on all tables
ALTER TABLE habits ENABLE ROW LEVEL SECURITY;
ALTER TABLE habit_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE todos ENABLE ROW LEVEL SECURITY;
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;

-- Habits policies
CREATE POLICY "Users can create their own habits"
  ON habits FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own habits"
  ON habits FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own habits"
  ON habits FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own habits"
  ON habits FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Habit completions policies
CREATE POLICY "Users can create completions for their habits"
  ON habit_completions FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view completions for their habits"
  ON habit_completions FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete completions for their habits"
  ON habit_completions FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Todos policies
CREATE POLICY "Users can create their own todos"
  ON todos FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own todos"
  ON todos FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own todos"
  ON todos FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own todos"
  ON todos FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Notes policies
CREATE POLICY "Users can create their own notes"
  ON notes FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own notes"
  ON notes FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notes"
  ON notes FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own notes"
  ON notes FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_todos_reminder_at ON todos (reminder_at)
WHERE reminder_at IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_todos_position ON todos (position);
CREATE INDEX IF NOT EXISTS idx_notes_position ON notes (position);