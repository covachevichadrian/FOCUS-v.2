/*
  # Add position field to todos

  1. Changes
    - Add position column to todos table for ordering
    - Set default position based on creation order
    - Add index for better query performance

  2. Security
    - Maintain existing RLS policies
*/

-- Add position column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'todos' 
    AND column_name = 'position'
  ) THEN
    ALTER TABLE todos ADD COLUMN position integer DEFAULT 0;
    
    -- Update existing todos with positions based on created_at
    WITH numbered_todos AS (
      SELECT id, ROW_NUMBER() OVER (ORDER BY created_at) as row_num
      FROM todos
    )
    UPDATE todos
    SET position = numbered_todos.row_num - 1
    FROM numbered_todos
    WHERE todos.id = numbered_todos.id;
  END IF;

  -- Create index for position if it doesn't exist
  IF NOT EXISTS (
    SELECT 1
    FROM pg_indexes
    WHERE tablename = 'todos'
    AND indexname = 'idx_todos_position'
  ) THEN
    CREATE INDEX idx_todos_position ON todos (position);
  END IF;
END $$;