-- Drop existing function first
DROP FUNCTION IF EXISTS should_update_recommendations(uuid, timestamp with time zone);

-- Create function to check if recommendations need updating
CREATE OR REPLACE FUNCTION should_update_recommendations(
  p_habit_id uuid,
  p_last_update timestamptz
)
RETURNS boolean AS $$
DECLARE
  habit_record habits%ROWTYPE;
  current_level text;
  stored_level text;
BEGIN
  -- Get habit information
  SELECT * INTO habit_record
  FROM habits
  WHERE id = p_habit_id;

  IF habit_record IS NULL THEN
    RETURN false;
  END IF;

  -- Determine current level
  current_level := CASE 
    WHEN habit_record.streak < 7 THEN 'beginner'
    WHEN habit_record.streak < 30 THEN 'intermediate'
    ELSE 'advanced'
  END;

  -- Get stored level
  SELECT level INTO stored_level
  FROM habit_recommendations
  WHERE habit_id = p_habit_id
  ORDER BY updated_at DESC
  LIMIT 1;

  -- Return true if:
  -- 1. Never updated before
  -- 2. Level has changed
  -- 3. Progress has been made
  -- 4. Last update was over a week ago
  RETURN (
    p_last_update IS NULL OR
    current_level != stored_level OR
    habit_record.last_progress_update > p_last_update OR
    p_last_update < NOW() - interval '1 week'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to update last_progress_update
CREATE OR REPLACE FUNCTION update_habit_progress()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE habits
  SET last_progress_update = NOW()
  WHERE id = COALESCE(NEW.habit_id, OLD.habit_id);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers for habit progress
DROP TRIGGER IF EXISTS habit_progress_completion_trigger ON habit_completions;
CREATE TRIGGER habit_progress_completion_trigger
AFTER INSERT OR DELETE ON habit_completions
FOR EACH ROW
EXECUTE FUNCTION update_habit_progress();

DROP TRIGGER IF EXISTS habit_progress_streak_trigger ON habits;
CREATE TRIGGER habit_progress_streak_trigger
AFTER UPDATE OF streak ON habits
FOR EACH ROW
WHEN (NEW.streak != OLD.streak)
EXECUTE FUNCTION update_habit_progress();