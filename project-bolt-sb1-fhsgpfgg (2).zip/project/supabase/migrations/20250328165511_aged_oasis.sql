/*
  # Simplify recommendations update check

  1. Changes
    - Modify should_update_recommendations to only check weekly updates
    - Remove progress tracking dependency
    - Keep level-based updates

  2. Details
    - Recommendations now update weekly regardless of habit progress
    - Still updates when user level changes (beginner/intermediate/advanced)
*/

-- Drop existing function
DROP FUNCTION IF EXISTS should_update_recommendations(uuid, timestamp with time zone);

-- Create simplified function
CREATE OR REPLACE FUNCTION should_update_recommendations(
  p_habit_id uuid,
  p_last_update timestamptz
)
RETURNS boolean AS $$
DECLARE
  habit_record habits%ROWTYPE;
  current_level text;
  stored_level text;
BEGIN
  -- Get habit information
  SELECT h.* INTO habit_record
  FROM habits h
  WHERE h.id = p_habit_id;

  IF habit_record IS NULL THEN
    RETURN false;
  END IF;

  -- Determine current level
  current_level := CASE 
    WHEN habit_record.streak < 7 THEN 'beginner'
    WHEN habit_record.streak < 30 THEN 'intermediate'
    ELSE 'advanced'
  END;

  -- Get stored level from recommendations
  SELECT level INTO stored_level
  FROM habit_recommendations
  WHERE habit_id = p_habit_id
  ORDER BY updated_at DESC
  LIMIT 1;

  -- Return true if:
  -- 1. Never updated before (p_last_update is null)
  -- 2. Level has changed
  -- 3. Last update was over a week ago
  RETURN (
    p_last_update IS NULL OR
    current_level != stored_level OR
    p_last_update < NOW() - interval '1 week'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;