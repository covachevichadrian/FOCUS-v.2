/*
  # Add unique constraint for book recommendations

  1. Changes
    - Add unique constraint on habit_id and title for habit_book_recommendations table
    - This enables proper upsert operations with ON CONFLICT

  2. Security
    - Maintain existing RLS policies
*/

-- Add unique constraint for habit_book_recommendations
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'habit_book_recommendations_habit_id_title_key'
  ) THEN
    ALTER TABLE habit_book_recommendations
    ADD CONSTRAINT habit_book_recommendations_habit_id_title_key
    UNIQUE (habit_id, title);
  END IF;
END $$;