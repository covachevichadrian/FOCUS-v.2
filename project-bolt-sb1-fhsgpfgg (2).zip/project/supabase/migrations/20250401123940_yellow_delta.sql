/*
  # Add deadline column to goals table

  1. Changes
    - Add deadline column to goals table
    - Make it nullable to support goals without deadlines
    - Add index for better query performance

  2. Notes
    - Uses timestamptz to store deadline with timezone information
    - Maintains existing RLS policies
*/

-- Add deadline column to goals table
ALTER TABLE goals ADD COLUMN IF NOT EXISTS deadline timestamptz;

-- Create index for deadline if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_goals_deadline ON goals (deadline)
WHERE deadline IS NOT NULL;