/*
  # Initial Schema Setup

  1. Tables
    - habits
    - habit_completions
    - todos
    - notes

  2. Security
    - RLS policies for all tables
    - Authentication settings
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Configure auth settings
ALTER ROLE authenticated SET statement_timeout = '8s';
ALTER ROLE service_role SET statement_timeout = '2h';
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DO $$ 
BEGIN
  -- Drop habits policies
  DROP POLICY IF EXISTS "Users can create their own habits" ON habits;
  DROP POLICY IF EXISTS "Users can view their own habits" ON habits;
  DROP POLICY IF EXISTS "Users can update their own habits" ON habits;
  DROP POLICY IF EXISTS "Users can delete their own habits" ON habits;

  -- Drop habit completions policies
  DROP POLICY IF EXISTS "Users can create completions for their habits" ON habit_completions;
  DROP POLICY IF EXISTS "Users can view completions for their habits" ON habit_completions;
  DROP POLICY IF EXISTS "Users can delete completions for their habits" ON habit_completions;

  -- Drop todos policies
  DROP POLICY IF EXISTS "Users can create their own todos" ON todos;
  DROP POLICY IF EXISTS "Users can view their own todos" ON todos;
  DROP POLICY IF EXISTS "Users can update their own todos" ON todos;
  DROP POLICY IF EXISTS "Users can delete their own todos" ON todos;

  -- Drop notes policies
  DROP POLICY IF EXISTS "Users can create their own notes" ON notes;
  DROP POLICY IF EXISTS "Users can view their own notes" ON notes;
  DROP POLICY IF EXISTS "Users can update their own notes" ON notes;
  DROP POLICY IF EXISTS "Users can delete their own notes" ON notes;
END $$;

-- Create habits table
CREATE TABLE IF NOT EXISTS habits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  streak integer DEFAULT 0,
  active_days integer[] DEFAULT ARRAY[0,1,2,3,4,5,6],
  CONSTRAINT valid_active_days CHECK (
    array_length(active_days, 1) > 0 
    AND array_length(active_days, 1) <= 7
    AND active_days <@ ARRAY[0,1,2,3,4,5,6]
  )
);

-- Create habit completions table
CREATE TABLE IF NOT EXISTS habit_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  completed_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create todos table
CREATE TABLE IF NOT EXISTS todos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL DEFAULT auth.uid(),
  title text NOT NULL,
  description text,
  completed boolean DEFAULT false,
  reminder_at timestamptz,
  reminder_sent boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  position integer DEFAULT 0
);

-- Create notes table
CREATE TABLE IF NOT EXISTS notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL DEFAULT auth.uid(),
  title text NOT NULL,
  content text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  position integer DEFAULT 0
);

-- Enable RLS on all tables
ALTER TABLE habits ENABLE ROW LEVEL SECURITY;
ALTER TABLE habit_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE todos ENABLE ROW LEVEL SECURITY;
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;

-- Habits policies
CREATE POLICY "Users can create their own habits"
  ON habits FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own habits"
  ON habits FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own habits"
  ON habits FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own habits"
  ON habits FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Habit completions policies
CREATE POLICY "Users can create completions for their habits"
  ON habit_completions FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view completions for their habits"
  ON habit_completions FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete completions for their habits"
  ON habit_completions FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Todos policies
CREATE POLICY "Users can create their own todos"
  ON todos FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own todos"
  ON todos FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own todos"
  ON todos FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own todos"
  ON todos FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Notes policies
CREATE POLICY "Users can create their own notes"
  ON notes FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own notes"
  ON notes FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notes"
  ON notes FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own notes"
  ON notes FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_todos_reminder_at ON todos (reminder_at)
WHERE reminder_at IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_todos_position ON todos (position);
CREATE INDEX IF NOT EXISTS idx_notes_position ON notes (position);

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS update_habit_streak_trigger ON habit_completions;
DROP FUNCTION IF EXISTS update_habit_streak;

-- Create function to update streak
CREATE OR REPLACE FUNCTION update_habit_streak()
RETURNS TRIGGER AS $$
DECLARE
  habit_record habits%ROWTYPE;
  current_streak integer := 0;
  check_date date;
  completion_exists boolean;
  is_active_day boolean;
  completion_count integer;
BEGIN
  -- Get habit information
  SELECT * INTO habit_record
  FROM habits
  WHERE id = COALESCE(NEW.habit_id, OLD.habit_id);

  -- Count total completions for this habit
  SELECT COUNT(*) INTO completion_count
  FROM habit_completions
  WHERE habit_id = habit_record.id;

  -- If this is the first completion ever, set streak to 1
  IF completion_count = 1 THEN
    current_streak := 1;
  ELSE
    -- Start from the most recent completion
    SELECT MAX(completed_at::date) INTO check_date
    FROM habit_completions
    WHERE habit_id = habit_record.id;

    -- If we have at least one completion
    IF check_date IS NOT NULL THEN
      current_streak := 1;
      
      -- Check previous days until we find a break in the streak
      LOOP
        check_date := check_date - interval '1 day';
        
        -- Check if this is an active day
        is_active_day := EXTRACT(DOW FROM check_date)::integer = ANY(habit_record.active_days);
        
        -- Only check completions for active days
        IF is_active_day THEN
          -- Check if the habit was completed on this date
          SELECT EXISTS (
            SELECT 1
            FROM habit_completions
            WHERE habit_id = habit_record.id
            AND completed_at::date = check_date
          ) INTO completion_exists;
          
          -- If we missed an active day, break the streak
          IF NOT completion_exists THEN
            EXIT;
          END IF;
          
          -- Increment streak for completed active days
          current_streak := current_streak + 1;
        END IF;
        
        -- Stop if we've gone too far back (safety check)
        IF check_date < (NOW() - interval '1 year') THEN
          EXIT;
        END IF;
      END LOOP;
    END IF;
  END IF;

  -- Update the streak
  UPDATE habits 
  SET streak = current_streak
  WHERE id = habit_record.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for habit_completions
CREATE TRIGGER update_habit_streak_trigger
AFTER INSERT OR DELETE ON habit_completions
FOR EACH ROW
EXECUTE FUNCTION update_habit_streak();