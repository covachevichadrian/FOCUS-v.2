/*
  # Fix habit streak calculation

  1. Changes
    - Improve streak calculation logic
    - Better handling of active days
    - Fix consecutive days check
    - Add proper error handling

  2. Details
    - Only counts consecutive completions on active days
    - Resets streak when an active day is missed
    - Properly handles weekends and non-active days
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS update_habit_streak_trigger ON habit_completions;
DROP FUNCTION IF EXISTS update_habit_streak;

-- Create updated trigger function
CREATE OR REPLACE FUNCTION update_habit_streak()
RETURNS TRIGGER AS $$
DECLARE
  habit_record habits%ROWTYPE;
  current_streak integer := 0;
  last_completion_date date;
  current_date date;
  check_date date;
  completion_exists boolean;
  is_active_day boolean;
  active_days_between boolean;
BEGIN
  -- Get habit information
  SELECT h.* INTO habit_record
  FROM habits h
  WHERE h.id = COALESCE(NEW.habit_id, OLD.habit_id);

  IF habit_record IS NULL THEN
    RAISE EXCEPTION 'Habit not found';
  END IF;

  -- Get the most recent completion date
  SELECT MAX(hc.completed_at::date)
  INTO current_date
  FROM habit_completions hc
  WHERE hc.habit_id = habit_record.id;

  -- If we have a completion
  IF current_date IS NOT NULL THEN
    -- Initialize streak counter
    current_streak := 1;
    check_date := current_date - interval '1 day';

    -- Count backwards until we find a gap
    LOOP
      -- Check if this is an active day
      is_active_day := EXTRACT(DOW FROM check_date)::integer = ANY(habit_record.active_days);

      IF is_active_day THEN
        -- Check if the habit was completed on this date
        SELECT EXISTS (
          SELECT 1
          FROM habit_completions hc
          WHERE hc.habit_id = habit_record.id
          AND hc.completed_at::date = check_date
        ) INTO completion_exists;

        -- If we missed an active day, break the streak
        IF NOT completion_exists THEN
          EXIT;
        END IF;

        -- Increment streak for completed active days
        current_streak := current_streak + 1;
      END IF;

      -- Move to previous day
      check_date := check_date - interval '1 day';

      -- Stop if we've gone too far back (safety check)
      IF check_date < (current_date - interval '1 year') THEN
        EXIT;
      END IF;

      -- Check if there are any active days between the current date and check_date
      SELECT EXISTS (
        SELECT 1
        FROM generate_series(check_date, current_date, interval '1 day') d
        WHERE EXTRACT(DOW FROM d)::integer = ANY(habit_record.active_days)
      ) INTO active_days_between;

      -- If there are no more active days to check, exit
      IF NOT active_days_between THEN
        EXIT;
      END IF;
    END LOOP;
  END IF;

  -- Update the streak
  UPDATE habits h
  SET 
    streak = current_streak,
    last_progress_update = NOW()
  WHERE h.id = habit_record.id;

  -- Return the appropriate record
  IF TG_OP = 'INSERT' THEN
    RETURN NEW;
  ELSE
    RETURN OLD;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new trigger
CREATE TRIGGER update_habit_streak_trigger
AFTER INSERT OR DELETE ON habit_completions
FOR EACH ROW
EXECUTE FUNCTION update_habit_streak();