/*
  # Fix habit streak calculation

  1. Changes
    - Improve streak calculation to handle consecutive active days correctly
    - Fix issue with completion_date reference
    - Add better handling of gaps between completions

  2. Details
    - Only counts consecutive completions on active days
    - Resets streak when an active day is missed
    - Properly handles weekends and non-active days
*/

CREATE OR REPLACE FUNCTION update_habit_streak()
RETURNS TRIGGER AS $$
DECLARE
  habit_record RECORD;
  current_streak integer := 0;
  last_date date;
  current_date date;
BEGIN
  -- Get habit information
  SELECT * INTO habit_record
  FROM habits
  WHERE id = COALESCE(NEW.habit_id, OLD.habit_id);

  -- Get the most recent completion
  SELECT completed_at::date INTO current_date
  FROM habit_completions
  WHERE habit_id = habit_record.id
  ORDER BY completed_at DESC
  LIMIT 1;

  -- If we have a completion
  IF current_date IS NOT NULL THEN
    -- Initialize streak counter
    current_streak := 1;
    last_date := current_date - interval '1 day';

    -- Count backwards until we find a gap
    WHILE EXISTS (
      SELECT 1
      FROM habit_completions
      WHERE habit_id = habit_record.id
      AND completed_at::date = last_date
      AND EXTRACT(DOW FROM completed_at)::integer = ANY(habit_record.active_days)
    ) LOOP
      current_streak := current_streak + 1;
      last_date := last_date - interval '1 day';
    END LOOP;

    -- Check if we broke the streak by missing an active day
    IF EXISTS (
      SELECT 1
      FROM generate_series(last_date, current_date, interval '1 day') as d
      WHERE EXTRACT(DOW FROM d)::integer = ANY(habit_record.active_days)
      AND NOT EXISTS (
        SELECT 1
        FROM habit_completions
        WHERE habit_id = habit_record.id
        AND completed_at::date = d
      )
      AND d != current_date
    ) THEN
      current_streak := 1;
    END IF;
  END IF;

  -- Update the streak
  UPDATE habits 
  SET streak = current_streak
  WHERE id = habit_record.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;