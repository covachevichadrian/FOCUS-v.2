-- Add color column to goals table
ALTER TABLE goals ADD COLUMN IF NOT EXISTS color text DEFAULT 'blue';