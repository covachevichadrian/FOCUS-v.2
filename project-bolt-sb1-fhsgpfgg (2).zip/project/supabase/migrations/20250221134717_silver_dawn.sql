/*
  # Add description field to todos

  1. Changes
    - Add description column to todos table
    - Make it optional (nullable)

  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'todos' 
    AND column_name = 'description'
  ) THEN
    ALTER TABLE todos ADD COLUMN description text;
  END IF;
END $$;