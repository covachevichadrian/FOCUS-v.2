/*
  # Add Recommendations Tables

  1. New Tables
    - habit_recommendations
      - For storing habit-specific recommendations
      - Includes type (tip, milestone, challenge, warning)
      - Tracks user progress and level
    
    - habit_book_recommendations
      - For storing book recommendations per habit
      - Includes book details and progress tracking

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create habit recommendations table
CREATE TABLE habit_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  type text NOT NULL CHECK (type IN ('tip', 'milestone', 'challenge', 'warning')),
  level text NOT NULL CHECK (level IN ('beginner', 'intermediate', 'advanced')),
  progress_snapshot jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_viewed_at timestamptz,
  CONSTRAINT habit_recommendations_habit_id_type_key UNIQUE (habit_id, type)
);

-- Create habit book recommendations table
CREATE TABLE habit_book_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  authors text[] NOT NULL,
  description text NOT NULL,
  image_url text,
  preview_link text,
  progress_snapshot jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_viewed_at timestamptz,
  CONSTRAINT habit_book_recommendations_habit_id_title_key UNIQUE (habit_id, title)
);

-- Enable RLS
ALTER TABLE habit_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE habit_book_recommendations ENABLE ROW LEVEL SECURITY;

-- Habit recommendations policies
CREATE POLICY "Users can create recommendations for their habits"
  ON habit_recommendations FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view recommendations for their habits"
  ON habit_recommendations FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update recommendations for their habits"
  ON habit_recommendations FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Book recommendations policies
CREATE POLICY "Users can create book recommendations for their habits"
  ON habit_book_recommendations FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view book recommendations for their habits"
  ON habit_book_recommendations FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update book recommendations for their habits"
  ON habit_book_recommendations FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Create function to check if recommendations need updating
CREATE OR REPLACE FUNCTION should_update_recommendations(
  p_habit_id uuid,
  p_last_update timestamptz
)
RETURNS boolean AS $$
DECLARE
  habit_record habits%ROWTYPE;
  current_level text;
  stored_level text;
BEGIN
  -- Get habit information
  SELECT h.* INTO habit_record
  FROM habits h
  WHERE h.id = p_habit_id;

  IF habit_record IS NULL THEN
    RETURN false;
  END IF;

  -- Determine current level
  current_level := CASE 
    WHEN habit_record.streak < 7 THEN 'beginner'
    WHEN habit_record.streak < 30 THEN 'intermediate'
    ELSE 'advanced'
  END;

  -- Get stored level from recommendations
  SELECT level INTO stored_level
  FROM habit_recommendations
  WHERE habit_id = p_habit_id
  ORDER BY updated_at DESC
  LIMIT 1;

  -- Return true if:
  -- 1. Never updated before (p_last_update is null)
  -- 2. Level has changed
  -- 3. Last update was over a week ago
  RETURN (
    p_last_update IS NULL OR
    current_level != stored_level OR
    p_last_update < NOW() - interval '1 week'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;