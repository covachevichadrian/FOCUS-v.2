/*
  # Update Habit Recommendations System - Part 2

  1. Changes
    - Add constraints for recommendation types and levels
*/

-- Drop existing constraints if they exist
DO $$ 
BEGIN
  ALTER TABLE habit_recommendations DROP CONSTRAINT IF EXISTS habit_recommendations_type_check;
  ALTER TABLE habit_recommendations DROP CONSTRAINT IF EXISTS habit_recommendations_level_check;
END $$;

-- Add new constraints
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'habit_recommendations_type_check'
  ) THEN
    ALTER TABLE habit_recommendations 
    ADD CONSTRAINT habit_recommendations_type_check 
    CHECK (type IN ('tip', 'milestone', 'challenge', 'warning'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'habit_recommendations_level_check'
  ) THEN
    ALTER TABLE habit_recommendations 
    ADD CONSTRAINT habit_recommendations_level_check 
    CHECK (level IN ('beginner', 'intermediate', 'advanced'));
  END IF;
END $$;