/*
  # Add active_days to habits table

  1. Changes
    - Add `active_days` column to `habits` table to store the days of the week when each habit should be performed
    - Default to all days of the week (0-6) for existing habits
    - Add validation to ensure active_days only contains valid day numbers (0-6)

  2. Notes
    - Uses integer array to store days of the week (0 = Sunday, 6 = Saturday)
    - Existing habits will be set to active all days by default
*/

-- Add active_days column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'habits' 
    AND column_name = 'active_days'
  ) THEN
    -- Add the column with a default value of all days
    ALTER TABLE habits 
    ADD COLUMN active_days integer[] DEFAULT ARRAY[0,1,2,3,4,5,6];

    -- Add check constraint to ensure valid day numbers
    ALTER TABLE habits
    ADD CONSTRAINT valid_active_days 
    CHECK (
      array_length(active_days, 1) > 0 
      AND array_length(active_days, 1) <= 7
      AND active_days <@ ARRAY[0,1,2,3,4,5,6]
    );
  END IF;
END $$;