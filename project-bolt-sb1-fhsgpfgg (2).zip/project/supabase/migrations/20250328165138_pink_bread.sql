/*
  # Fix ambiguous column references

  1. Changes
    - Qualify all column references with their table names
    - Improve SQL query clarity
    - Fix ambiguous habit_id references
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS update_habit_streak_trigger ON habit_completions;
DROP FUNCTION IF EXISTS update_habit_streak;

-- Create updated trigger function
CREATE OR REPLACE FUNCTION update_habit_streak()
RETURNS TRIGGER AS $$
DECLARE
  habit_record habits%ROWTYPE;
  current_streak integer := 0;
  check_date date;
  completion_exists boolean;
  is_active_day boolean;
  completion_count integer;
  habit_id uuid;
BEGIN
  -- Get the habit_id based on operation type
  IF TG_OP = 'INSERT' THEN
    habit_id := NEW.habit_id;
  ELSE
    habit_id := OLD.habit_id;
  END IF;

  -- Get habit information
  SELECT h.* INTO habit_record
  FROM habits h
  WHERE h.id = habit_id;

  IF habit_record IS NULL THEN
    RAISE EXCEPTION 'Habit not found';
  END IF;

  -- Count total completions for this habit
  SELECT COUNT(*) INTO completion_count
  FROM habit_completions hc
  WHERE hc.habit_id = habit_record.id;

  -- If this is the first completion ever, set streak to 1
  IF TG_OP = 'INSERT' AND completion_count = 1 THEN
    current_streak := 1;
  ELSE
    -- Start from the most recent completion
    SELECT MAX(hc.completed_at::date) INTO check_date
    FROM habit_completions hc
    WHERE hc.habit_id = habit_record.id;

    -- If we have at least one completion
    IF check_date IS NOT NULL THEN
      current_streak := 1;
      
      -- Check previous days until we find a break in the streak
      LOOP
        check_date := check_date - interval '1 day';
        
        -- Check if this is an active day
        is_active_day := EXTRACT(DOW FROM check_date)::integer = ANY(habit_record.active_days);
        
        -- Only check completions for active days
        IF is_active_day THEN
          -- Check if the habit was completed on this date
          SELECT EXISTS (
            SELECT 1
            FROM habit_completions hc
            WHERE hc.habit_id = habit_record.id
            AND hc.completed_at::date = check_date
          ) INTO completion_exists;
          
          -- If we missed an active day, break the streak
          IF NOT completion_exists THEN
            EXIT;
          END IF;
          
          -- Increment streak for completed active days
          current_streak := current_streak + 1;
        END IF;
        
        -- Stop if we've gone too far back (safety check)
        IF check_date < (NOW() - interval '1 year') THEN
          EXIT;
        END IF;
      END LOOP;
    END IF;
  END IF;

  -- Update the streak
  UPDATE habits h
  SET streak = current_streak
  WHERE h.id = habit_record.id;

  -- Return the appropriate record
  IF TG_OP = 'INSERT' THEN
    RETURN NEW;
  ELSE
    RETURN OLD;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new trigger
CREATE TRIGGER update_habit_streak_trigger
AFTER INSERT OR DELETE ON habit_completions
FOR EACH ROW
EXECUTE FUNCTION update_habit_streak();