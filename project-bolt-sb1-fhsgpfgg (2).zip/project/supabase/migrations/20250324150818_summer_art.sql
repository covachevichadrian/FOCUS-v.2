/*
  # Add recommendations tables

  1. New Tables
    - `habit_recommendations`
      - `id` (uuid, primary key)
      - `habit_id` (uuid, references habits)
      - `title` (text)
      - `description` (text)
      - `type` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `last_viewed_at` (timestamptz)

    - `habit_book_recommendations`
      - `id` (uuid, primary key)
      - `habit_id` (uuid, references habits)
      - `title` (text)
      - `authors` (text[])
      - `description` (text)
      - `image_url` (text)
      - `preview_link` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `last_viewed_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create habit recommendations table
CREATE TABLE IF NOT EXISTS habit_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  type text NOT NULL CHECK (type IN ('tip', 'milestone', 'challenge', 'warning')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_viewed_at timestamptz
);

-- Create habit book recommendations table
CREATE TABLE IF NOT EXISTS habit_book_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  habit_id uuid REFERENCES habits ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  authors text[] NOT NULL,
  description text NOT NULL,
  image_url text,
  preview_link text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_viewed_at timestamptz
);

-- Enable RLS
ALTER TABLE habit_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE habit_book_recommendations ENABLE ROW LEVEL SECURITY;

-- Habit recommendations policies
CREATE POLICY "Users can view recommendations for their habits"
  ON habit_recommendations FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update recommendations for their habits"
  ON habit_recommendations FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Book recommendations policies
CREATE POLICY "Users can view book recommendations for their habits"
  ON habit_book_recommendations FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update book recommendations for their habits"
  ON habit_book_recommendations FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM habits
      WHERE id = habit_id
      AND user_id = auth.uid()
    )
  );

-- Function to check if recommendations need updating
CREATE OR REPLACE FUNCTION should_update_recommendations(
  habit_id uuid,
  last_viewed timestamp with time zone
)
RETURNS boolean AS $$
DECLARE
  habit_record habits%ROWTYPE;
  last_completion_date date;
  has_progress boolean;
BEGIN
  -- Get habit information
  SELECT * INTO habit_record
  FROM habits
  WHERE id = habit_id;

  -- Get last completion date
  SELECT MAX(completed_at::date) INTO last_completion_date
  FROM habit_completions
  WHERE habit_id = habit_record.id;

  -- Check if there's been progress since last view
  has_progress := last_completion_date > (last_viewed::date);

  -- Return true if:
  -- 1. Never viewed before (last_viewed is null)
  -- 2. Has progress since last view
  -- 3. Last viewed was more than a week ago
  RETURN (
    last_viewed IS NULL OR
    has_progress OR
    (last_viewed < NOW() - interval '1 week')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;