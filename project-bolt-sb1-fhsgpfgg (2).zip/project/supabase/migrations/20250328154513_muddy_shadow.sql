-- Add unique constraint for habit_recommendations
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'habit_recommendations_habit_id_type_key'
  ) THEN
    ALTER TABLE habit_recommendations
    ADD CONSTRAINT habit_recommendations_habit_id_type_key
    UNIQUE (habit_id, type);
  END IF;
END $$;