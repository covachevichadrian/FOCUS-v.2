/*
  # Fix habit streak calculation

  1. Changes
    - Improve streak calculation to handle consecutive active days correctly
    - Reset streak when missing an active day
    - Properly handle non-active days

  2. Details
    - Only counts consecutive completions on active days
    - Resets streak when an active day is missed
    - Ignores non-active days in streak calculation
*/

CREATE OR REPLACE FUNCTION update_habit_streak()
RETURNS TRIGGER AS $$
DECLARE
  habit_record RECORD;
  current_streak integer := 0;
  max_streak integer := 0;
  check_date date;
  completion_exists boolean;
  is_active_day boolean;
BEGIN
  -- Get habit information
  SELECT * INTO habit_record
  FROM habits
  WHERE id = COALESCE(NEW.habit_id, OLD.habit_id);

  -- Start from the most recent completion
  SELECT MAX(completed_at::date) INTO check_date
  FROM habit_completions
  WHERE habit_id = habit_record.id;

  -- If we have at least one completion
  IF check_date IS NOT NULL THEN
    current_streak := 1;
    
    -- Check previous days until we find a break in the streak
    LOOP
      check_date := check_date - interval '1 day';
      
      -- Check if this is an active day
      is_active_day := EXTRACT(DOW FROM check_date)::integer = ANY(habit_record.active_days);
      
      -- Only check completions for active days
      IF is_active_day THEN
        -- Check if the habit was completed on this date
        SELECT EXISTS (
          SELECT 1
          FROM habit_completions
          WHERE habit_id = habit_record.id
          AND completed_at::date = check_date
        ) INTO completion_exists;
        
        -- If we missed an active day, break the streak
        IF NOT completion_exists THEN
          EXIT;
        END IF;
        
        -- Increment streak for completed active days
        current_streak := current_streak + 1;
      END IF;
      
      -- Stop if we've gone too far back (safety check)
      IF check_date < (NOW() - interval '1 year') THEN
        EXIT;
      END IF;
    END LOOP;
  END IF;

  -- Update the streak
  UPDATE habits 
  SET streak = current_streak
  WHERE id = habit_record.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;