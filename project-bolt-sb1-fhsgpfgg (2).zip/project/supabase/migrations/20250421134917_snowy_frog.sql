/*
  # Add Chat History Table

  1. New Table
    - `goal_chat_history`
      - `id` (uuid, primary key)
      - `goal_id` (uuid, references goals)
      - `role` (text)
      - `content` (text)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create chat history table
CREATE TABLE goal_chat_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  goal_id uuid REFERENCES goals ON DELETE CASCADE NOT NULL,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE goal_chat_history ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can create chat messages for their goals"
  ON goal_chat_history FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view chat messages for their goals"
  ON goal_chat_history FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

-- Create index for better query performance
CREATE INDEX idx_goal_chat_history_goal_id ON goal_chat_history (goal_id);