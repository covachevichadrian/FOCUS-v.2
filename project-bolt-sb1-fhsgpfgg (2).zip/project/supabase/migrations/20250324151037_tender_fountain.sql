/*
  # Fix recommendations function parameter name

  1. Changes
    - Drop existing function before recreating it
    - Fix ambiguous column references
    - Improve function logic and clarity
*/

-- Drop existing function
DROP FUNCTION IF EXISTS should_update_recommendations(uuid, timestamp with time zone);

-- Recreate function with fixed parameter name
CREATE OR REPLACE FUNCTION should_update_recommendations(
  p_habit_id uuid,
  p_last_viewed timestamp with time zone
)
RETURNS boolean AS $$
DECLARE
  habit_record habits%ROWTYPE;
  last_completion_date date;
  has_progress boolean;
BEGIN
  -- Get habit information
  SELECT *
  INTO habit_record
  FROM habits h
  WHERE h.id = p_habit_id;

  -- If habit doesn't exist, return false
  IF habit_record IS NULL THEN
    RETURN false;
  END IF;

  -- Get last completion date
  SELECT MAX(hc.completed_at::date)
  INTO last_completion_date
  FROM habit_completions hc
  WHERE hc.habit_id = p_habit_id;

  -- Check if there's been progress since last view
  has_progress := last_completion_date IS NOT NULL AND 
                 (p_last_viewed IS NULL OR last_completion_date > p_last_viewed::date);

  -- Return true if:
  -- 1. Never viewed before (p_last_viewed is null)
  -- 2. Has progress since last view
  -- 3. Last viewed was more than a week ago
  RETURN (
    p_last_viewed IS NULL OR
    has_progress OR
    (p_last_viewed < NOW() - interval '1 week')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;