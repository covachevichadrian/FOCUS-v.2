/*
  # Update habits schema with user_id default

  This migration updates the habits table to automatically set the user_id
  to the authenticated user's ID when creating new habits.

  Changes:
  - Add DEFAULT auth.uid() to user_id column in habits table
*/

DO $$ 
BEGIN
  -- Update habits table to set default user_id if the column exists
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'habits' 
    AND column_name = 'user_id'
  ) THEN
    ALTER TABLE habits 
    ALTER COLUMN user_id SET DEFAULT auth.uid();
  END IF;
END $$;