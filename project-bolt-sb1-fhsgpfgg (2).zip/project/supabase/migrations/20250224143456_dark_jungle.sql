/*
  # Actualizar lógica de streak para días activos consecutivos

  1. Cambios
    - Actualiza la función `update_habit_streak` para contar solo días activos consecutivos
    - El streak se reinicia si se salta un día activo
    - Los días no activos no afectan el streak

  2. Detalles
    - Usa una ventana de tiempo para encontrar días consecutivos
    - Verifica que los días completados sean días activos del hábito
    - Calcula el streak más largo actual
*/

-- Reemplazar la función existente
CREATE OR REPLACE FUNCTION update_habit_streak()
RETURNS TRIGGER AS $$
DECLARE
  habit_record RECORD;
  current_streak integer := 0;
  last_completion_date date := NULL;
BEGIN
  -- Obtener información del hábito
  SELECT * INTO habit_record
  FROM habits
  WHERE id = COALESCE(NEW.habit_id, OLD.habit_id);

  -- Obtener todas las completaciones ordenadas por fecha
  WITH dated_completions AS (
    SELECT 
      DISTINCT date_trunc('day', completed_at)::date as completion_date
    FROM habit_completions
    WHERE habit_id = habit_record.id
    ORDER BY completion_date DESC
  )
  SELECT 
    COUNT(*) INTO current_streak
  FROM (
    SELECT 
      completion_date,
      EXTRACT(DOW FROM completion_date)::integer as day_of_week,
      completion_date - ROW_NUMBER() OVER (ORDER BY completion_date DESC) * INTERVAL '1 day' as group_date
    FROM dated_completions
    WHERE EXTRACT(DOW FROM completion_date)::integer = ANY(habit_record.active_days)
  ) grouped
  WHERE group_date = (
    SELECT MIN(group_date)
    FROM (
      SELECT 
        completion_date - ROW_NUMBER() OVER (ORDER BY completion_date DESC) * INTERVAL '1 day' as group_date
      FROM dated_completions
      WHERE EXTRACT(DOW FROM completion_date)::integer = ANY(habit_record.active_days)
    ) latest_group
  );

  -- Actualizar el streak en la tabla de hábitos
  UPDATE habits 
  SET streak = current_streak
  WHERE id = habit_record.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;