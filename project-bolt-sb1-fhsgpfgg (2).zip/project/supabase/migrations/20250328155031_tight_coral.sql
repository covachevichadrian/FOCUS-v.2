/*
  # Add progress tracking to book recommendations

  1. Changes
    - Add progress_snapshot column to habit_book_recommendations table
    - This enables tracking user progress when books were recommended
    - Helps determine when to refresh recommendations

  2. Security
    - Maintain existing RLS policies
*/

-- Add progress_snapshot column to habit_book_recommendations
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'habit_book_recommendations' 
    AND column_name = 'progress_snapshot'
  ) THEN
    ALTER TABLE habit_book_recommendations 
    ADD COLUMN progress_snapshot jsonb;
  END IF;
END $$;