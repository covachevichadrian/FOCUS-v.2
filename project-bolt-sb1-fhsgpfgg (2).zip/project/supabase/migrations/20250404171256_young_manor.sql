-- Add color column to goals table with default value
ALTER TABLE goals ADD COLUMN IF NOT EXISTS color text DEFAULT 'blue'::text;

-- Add check constraint for valid colors
ALTER TABLE goals ADD CONSTRAINT valid_goal_color 
  CHECK (color IN ('blue', 'purple', 'green', 'rose', 'amber', 'cyan'));