/*
  # Update Habit Recommendations System - Part 1

  1. Changes
    - Add progress tracking columns to habits
    - Add progress snapshot and level to recommendations
    - Add constraints for recommendation types

  2. Notes
    - Split into multiple migrations to avoid timeout
    - This migration handles schema changes only
*/

-- Add progress tracking columns to habits
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'habits' 
    AND column_name = 'last_progress_update'
  ) THEN
    ALTER TABLE habits ADD COLUMN last_progress_update timestamptz;
  END IF;
END $$;

-- Update habit_recommendations table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'habit_recommendations' 
    AND column_name = 'progress_snapshot'
  ) THEN
    ALTER TABLE habit_recommendations ADD COLUMN progress_snapshot jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'habit_recommendations' 
    AND column_name = 'level'
  ) THEN
    ALTER TABLE habit_recommendations ADD COLUMN level text;
  END IF;
END $$;