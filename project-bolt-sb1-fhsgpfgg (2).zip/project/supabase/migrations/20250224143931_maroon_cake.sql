/*
  # Actualizar lógica de streak para días consecutivos

  1. Cambios
    - Actualiza la función `update_habit_streak` para contar solo días consecutivos
    - El streak se reinicia si se salta un día activo
    - Requiere al menos dos días consecutivos para empezar un nuevo streak

  2. Detalles
    - Usa window functions para detectar gaps en la secuencia
    - Solo considera días activos del hábito
    - Calcula el streak actual basado en la secuencia más reciente
*/

CREATE OR REPLACE FUNCTION update_habit_streak()
RETURNS TRIGGER AS $$
DECLARE
  habit_record RECORD;
  current_streak integer := 0;
  last_completion_date date := NULL;
BEGIN
  -- Obtener información del hábito
  SELECT * INTO habit_record
  FROM habits
  WHERE id = COALESCE(NEW.habit_id, OLD.habit_id);

  -- Calcular el streak actual
  WITH RECURSIVE 
    -- Primero obtenemos todas las fechas de completación
    dated_completions AS (
      SELECT DISTINCT date_trunc('day', completed_at)::date as completion_date
      FROM habit_completions
      WHERE habit_id = habit_record.id
      AND EXTRACT(DOW FROM completed_at)::integer = ANY(habit_record.active_days)
      ORDER BY completion_date DESC
    ),
    -- Luego identificamos los días activos que deberían haber sido completados
    active_days AS (
      SELECT 
        d::date as date,
        EXTRACT(DOW FROM d)::integer as dow
      FROM generate_series(
        (SELECT min(completion_date) FROM dated_completions),
        (SELECT max(completion_date) FROM dated_completions),
        '1 day'::interval
      ) d
      WHERE EXTRACT(DOW FROM d)::integer = ANY(habit_record.active_days)
    ),
    -- Finalmente calculamos el streak actual
    streak_calc AS (
      SELECT 
        completion_date,
        row_number() OVER (ORDER BY completion_date DESC) as rn
      FROM dated_completions
      WHERE completion_date >= (
        -- Encontrar el último día faltante
        SELECT COALESCE(
          (
            SELECT min(ad.date)
            FROM active_days ad
            LEFT JOIN dated_completions dc ON dc.completion_date = ad.date
            WHERE dc.completion_date IS NULL
            AND ad.date < (SELECT max(completion_date) FROM dated_completions)
          ),
          (SELECT min(completion_date) FROM dated_completions)
        )
      )
    )
  SELECT count(*) INTO current_streak
  FROM streak_calc;

  -- Si el streak es 1, verificamos si hay completaciones anteriores
  -- para determinar si debemos resetearlo a 0
  IF current_streak = 1 THEN
    SELECT max(completion_date) INTO last_completion_date
    FROM habit_completions
    WHERE habit_id = habit_record.id
    AND completed_at::date < (
      SELECT max(completion_date)
      FROM dated_completions
    );

    -- Si no hay completación anterior o si hay un gap, reseteamos el streak
    IF last_completion_date IS NULL OR (
      SELECT EXISTS (
        SELECT 1
        FROM active_days
        WHERE date > last_completion_date
        AND date < (SELECT max(completion_date) FROM dated_completions)
      )
    ) THEN
      current_streak := 0;
    END IF;
  END IF;

  -- Actualizar el streak en la tabla de hábitos
  UPDATE habits 
  SET streak = current_streak
  WHERE id = habit_record.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;