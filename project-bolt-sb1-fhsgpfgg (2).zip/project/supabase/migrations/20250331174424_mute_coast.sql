/*
  # Update Goals System

  1. Changes
    - Remove unique constraint on user_id to allow multiple goals
    - Add goal_recommendations table for storing AI recommendations
    - Add indexes for better query performance

  2. Security
    - Maintain existing RLS policies
    - Add policies for goal recommendations
*/

-- Drop unique constraint on user_id
ALTER TABLE goals DROP CONSTRAINT IF EXISTS unique_user_goal;

-- Create goal recommendations table
CREATE TABLE goal_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  goal_id uuid REFERENCES goals ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  type text NOT NULL CHECK (type IN ('action', 'insight', 'milestone')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on recommendations
ALTER TABLE goal_recommendations ENABLE ROW LEVEL SECURITY;

-- Create policies for goal recommendations
CREATE POLICY "Users can create recommendations for their goals"
  ON goal_recommendations FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view recommendations for their goals"
  ON goal_recommendations FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update recommendations for their goals"
  ON goal_recommendations FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete recommendations for their goals"
  ON goal_recommendations FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM goals
      WHERE id = goal_id
      AND user_id = auth.uid()
    )
  );

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_goals_user_id ON goals (user_id);
CREATE INDEX IF NOT EXISTS idx_goal_recommendations_goal_id ON goal_recommendations (goal_id);